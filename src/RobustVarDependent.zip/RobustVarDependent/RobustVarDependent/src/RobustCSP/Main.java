/**
 * This is the main class for the algorithm.
 * 
 * 
 */
package RobustCSP;

import ilog.concert.IloException;

import java.awt.DefaultFocusTraversalPolicy;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Random;

public class Main {

	public static void main(String[] args) throws IOException, InterruptedException, IloException {

		java.io.PrintStream ps = new java.io.PrintStream( new java.io.FileOutputStream("ResultsCSPLP.txt", true));
		
		//Define B
		int[] manteinanceBudgets={0};
		int[] uncertaintyBudgets={20};
		// Set the time limit
		int timeLimit = 3600;

		//Iterate over (Q,B) pairs
		for (int k = 0; k < uncertaintyBudgets.length; k++) {
			//ps.println("********************************************* "+dBudgets[k]+" "+aBudgets[k]+" **************************************************************");
			//Iterate over the network sizes
			for (int i = 1; i <= 1; i++) {
				//Iterate over the random instances	
				for	(int s = 1 ; s <= 9 ; s++) {
					//Iterate over the cost configurations
						// Read the data file and store the data on a DataHandler		
						DataHandler data = new DataHandler(s);
						data.ReadDimacs("data/Grid"+i+"0x"+i+"0_10-10_"+s+".txt");
						data.genRandomInstance();
						data.setResourceBudget(1.5);
						data.solveCSP();
						//data.PrintNetwork("TEST");
						
						//Set budgets
						data.uBudget = uncertaintyBudgets[k];
						data.mBudget = manteinanceBudgets[k];

						// Begin the time count						
						double Atime = System.currentTimeMillis();

						runCuttingPlane(data, Atime, timeLimit, ps);

					
				}
				//ps.println();
			}
		}
	}

	private static void runCuttingPlane(DataHandler data, double Atime, int timeLimit, PrintStream ps) throws InterruptedException, IloException {
		// Create an AlgorithmHandler
		AlgorithmHandler alg = new AlgorithmHandler(data);
		alg.cuttingPlane(data, Atime, timeLimit);

		System.out.println("Solved "+(System.currentTimeMillis()-Atime)/1000+" "+alg.LB+" "+alg.UB);
		ps.println("CutPlane "+data.CsvInput+" "+data.mBudget+" "+data.uBudget+" "+data.numNodes+" "+data.numArcs+" "+data.seed+" "+(System.currentTimeMillis()-Atime)/1000+" "+data.CSP+" "+alg.LB+" "+alg.UB+" "+alg.sample.size());
	}
}
