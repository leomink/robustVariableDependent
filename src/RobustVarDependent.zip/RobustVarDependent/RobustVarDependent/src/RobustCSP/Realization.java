package RobustCSP;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import ilog.concert.IloLinearNumExpr;

public class Realization {

	// Uncertainty vector
	double[] u;
	// Value to block the realization for each constraint
	int[] gamma; 

	Realization(DataHandler data){
		u = new double[data.numArcs];
		gamma = new int[data.numNodes]; //One region per node
	}

	public void print(DataHandler data) {
		//System.out.print("u: "+Arrays.toString(u));
		//System.out.println(" gamma: "+Arrays.toString(gamma));
		for (int i = 0; i < u.length; i++) {
			if(u[i] > 0) {
				System.out.println("FAILURE ARC "+data.arcs[i][0]+" to "+data.arcs[i][1]+": "+u[i]);
			}
		}
	}

	public void computeGamma(DataHandler data) {
		for(int j=0; j < data.numNodes; j++){
			for (int i = 0; i <data.numArcs; i++) {
				// Realization is blocked if a failure is inside the maintenance region
				if(u[i]>0 && data.region[j][data.arcs[i][0]]==1 && data.region[j][data.arcs[i][1]]==1) {
					//System.out.println("Arc from "+data.arcs[i][0]+" to "+data.arcs[i][1]+" blocked by region "+j);
					gamma[j] = 1;
				}

			}
		}

	}

}
