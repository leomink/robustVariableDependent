package RobustCSP;

import ilog.concert.*;
import ilog.cplex.*;
import ilog.cplex.IloCplex.UnknownObjectException;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Random;

public class AlgorithmHandler {

	int[] xstar; 								// Optimal solution
	int[] ystar; 								// Optimal solution
	int[] xbar; 								// Current solution
	int[] ybar; 								// Current solution
	int LB;
	int UB;
	ArrayList<Realization> sample;				// Current sample
	ArrayList<Integer>[] criticalPoints;		// Points to block realizations for each constraint
	IloCplex cplex;								// Cplex model

	public AlgorithmHandler(DataHandler data) throws InterruptedException, IloException {
		LB = -999999999;
		UB = 999999999;
		xstar = new int[data.numNodes]; //Maintenance plan
		ystar = new int[data.numArcs]; // Flow
		sample = new ArrayList<Realization>();
	}

	// Solves high point relaxation
	public void solveMaster(DataHandler data, int timeLim) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.Param.TimeLimit, timeLim);
		cplex.setOut(null);

		//Create variables
		IloNumVar[] y = new IloNumVar[data.numArcs]; // Flow
		IloNumVar[] x = new IloNumVar[data.numNodes]; // Maintenance
		for (int i = 0; i < data.numArcs; i++) {
			y[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "y["+i+"]");
		}
		for (int i = 0; i < data.numNodes; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
		}
		// Maintenance budget
		IloLinearNumExpr exprB = cplex.linearNumExpr();
		for (int i = 0; i < data.numNodes; i++) {
			exprB.addTerm(1, x[i]);
		}
		cplex.addLe(exprB, data.mBudget);

		// Add flow constraints (but drop the last one)
		IloLinearNumExpr[] expr = new IloLinearNumExpr[data.numNodes];
		for (int n = 0; n < data.numNodes; n++) {
			expr[n] = cplex.linearNumExpr();
		}	
		for (int i = 0; i < data.numArcs; i++) {
			int tail = data.arcs[i][0];
			int head = data.arcs[i][1];
			expr[tail].addTerm(1, y[i]);
			expr[head].addTerm(-1, y[i]);
		}

		// Flow for the nodes (omit the sink!)
		for (int n = 0; n < data.numNodes; n++) {
			if(n!=data.source && n!=data.lastNode){cplex.addEq(expr[n], 0, "flow_"+0+"_"+n);}
		}
		// Flow for the source
		cplex.addEq(expr[data.source], 1);

		// Resource constraints for each realization
		for (int h = 0; h < sample.size(); h++) {
			int rIncrease = 0;
			IloLinearNumExpr exprR = cplex.linearNumExpr();
			for (int i = 0; i < data.numArcs; i++) {
				exprR.addTerm(data.flowResource[i]*(1+1*sample.get(h).u[i]), y[i]);
				rIncrease += data.flowResource[i]*(1*sample.get(h).u[i]);
			}

			// Feasibility filter
			for (int q = 0; q < data.numNodes; q++) {
				if(sample.get(h).gamma[q] > 0) {
					exprR.addTerm(-rIncrease, x[q]);
				}
			}

			cplex.addLe(exprR, data.rBudget);

		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i<data.numArcs; i++){
			obj.addTerm(y[i], data.flowCost[i]);
		}	    	

		cplex.addMinimize(obj,"OBJ");

		// Optimize model
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Problem is infeasible!");
			LB = UB;
		}
		else if(cplex.getStatus() == IloCplex.Status.Optimal) {
			xbar = new int[data.numNodes];
			ybar = new int[data.numArcs];
			LB = (int) Math.round(cplex.getObjValue());
			System.out.println("***********************************  CURRENT LB: "+ LB);
			for (int i = 0; i < data.numArcs; i++) {
				ybar[i] = (int) round(cplex.getValue(y[i]));
				if(ybar[i] > 0.001) System.out.println("FLOW FROM "+data.arcs[i][0]+" to "+data.arcs[i][1]+" : "+ybar[i]);
			}
			for (int i = 0; i < data.numNodes; i++) {
				if(cplex.getValue(x[i]) > 0.001) {
					xbar[i] = 1;
					System.out.println("x_"+i+" = "+1);
				}

			}


		}
		else {
			System.out.println("ABORTED BECAUSE OF TIME LIMIT ");
		}
		cplex.clearModel();
		cplex=null;
		System.gc();
	}
	// Finds a realization to block ybar or determines it does not exist
	private void solveWorstCase(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setOut(null);
		//Uncertainty variables 
		IloNumVar[] u = new IloNumVar[data.numArcs];
		for (int i = 0; i < data.numArcs; i++) {
			u[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
			//u[i] = cplex.numVar(0, 1, IloNumVarType.Float);
		}
		// add constraints uncertainty set budget
		IloLinearNumExpr exprB = cplex.linearNumExpr();
		for (int i = 0; i < data.numArcs; i++) {
			exprB.addTerm(data.aWeight[i], u[i]);
		}
		cplex.addLe(exprB, data.uBudget);

		// Maintenance in each region
		for(int j=0; j < data.numNodes; j++){
			IloLinearNumExpr expr = cplex.linearNumExpr();
			int rhs = 0;
			//System.out.println("REGION "+j+" : ");
			for (int i = 0; i <data.numArcs; i++) {
				expr.addTerm(data.region[j][data.arcs[i][0]]*data.region[j][data.arcs[i][1]], u[i]);
				rhs += data.region[j][data.arcs[i][0]]*data.region[j][data.arcs[i][1]];
				//if(data.region[j][data.arcs[i][0]]*data.region[j][data.arcs[i][1]] == 1) {
					//System.out.println("   Arc "+i);
				//}
			}
			//System.out.println("rhs "+rhs);
			cplex.addLe(expr, rhs*(1-xbar[j]));
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION: Maximize resource utilization by the given path	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i < data.numArcs; i++){
				obj.addTerm( ybar[i]*1*data.flowResource[i] , u[i]);
		}
		cplex.addMaximize(obj,"OBJ");
		cplex.solve();
		
		int originalResource = 0; //Original resource consumption
		for(int i=0; i < data.numArcs; i++){
			originalResource += ybar[i]*data.flowResource[i];
		}
		double addResource = round(cplex.getObjValue()); //Additional resource consumption 
		//System.out.println("Original: "+originalResource);
		//System.out.println("Additional: "+addResource);
		
		if(originalResource+addResource <= data.rBudget) {
			UB = LB;
			double resource = 0; // Resource consumption double check
			for(int i=0; i < data.numArcs; i++){
				resource += ybar[i]*data.flowResource[i]*(1+1*cplex.getValue(u[i]));
			}
			System.out.println("Current solution cannot be blocked: "+resource+" <= "+data.rBudget);
			
		}
		else {
			System.out.println("Constraint violation "+(originalResource+addResource)+" vs "+data.rBudget);
			// Add realization to the sample
			Realization s = new Realization(data); //to add to the sample
			for (int i = 0; i < data.numArcs; i++) {
				if(cplex.getValue(u[i]) > 0.00001) {s.u[i] = round(cplex.getValue(u[i]));}
			}
			s.computeGamma(data); 
			s.print(data);
			sample.add(s);
		}

		cplex.clearModel();
		cplex=null;
		System.gc();
	}

	// gets an UB on the RHS
	public void initializeSample(DataHandler data) throws IloException {
		Realization s = new Realization(data); //to add to the sample
		s.computeGamma(data); 
		s.print(data);
		sample.add(s);
	}

	public void cuttingPlane(DataHandler data, double Atime, int timeLimit) throws IloException {

		int timeUsed = (int) ((System.currentTimeMillis()-Atime)/1000);
		initializeSample(data);		//Initialize sample
		//solveMaster(data, timeLimit-timeUsed);
		//solveWorstCase(data);
		

		while(UB > LB && timeUsed < timeLimit) {
			solveMaster(data, timeLimit-timeUsed);
			solveWorstCaseConnected(data);
			timeUsed = (int) ((System.currentTimeMillis()-Atime)/1000);
			System.out.println("************************************************** LB "+LB+" Sample Size: "+sample.size());
		}
		
	}

	private double round(double value) {
		double rounded;
		rounded = Math.round(value*10000)/10000.0;
		return rounded;
	}

	// Finds a realization to block ybar or determines it does not exist
	private void solveWorstCaseConnected(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setOut(null);
		//Uncertainty variables 
		IloNumVar[] u = new IloNumVar[data.numArcs];
		IloNumVar[] start = new IloNumVar[data.numArcs]; //Start of the chained failure
		for (int i = 0; i < data.numArcs; i++) {
			u[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
			//u[i] = cplex.numVar(0, 1, IloNumVarType.Float);
			
			start[i] = cplex.numVar(0, 1, IloNumVarType.Bool);
			//start[i] = cplex.numVar(0, 1, IloNumVarType.Float);
		}
		// add constraints uncertainty set budget
		IloLinearNumExpr exprB = cplex.linearNumExpr();
		for (int i = 0; i < data.numArcs; i++) {
			exprB.addTerm(data.aWeight[i], u[i]);
		}
		cplex.addLe(exprB, data.uBudget);

		// add constraints one start of chain
		IloLinearNumExpr exprS = cplex.linearNumExpr();
		for (int i = 0; i < data.numArcs; i++) {
			exprS.addTerm(1, start[i]);
		}
		cplex.addEq(exprS, 1);

		//Fails must be chained
		for (int i = 0; i < data.numArcs; i++) {
			IloLinearNumExpr exprC = cplex.linearNumExpr();
			exprC.addTerm(1, u[i]);
			for (int j = 0; j < data.numArcs; j++) {
				if(data.arcs[j][1] == data.arcs[i][0]) {
					exprC.addTerm(-1, u[j]);
				}
			}	

			exprC.addTerm(-1, start[i]);
			cplex.addLe(exprC, 0);
		}
				
		// Maintenance in each region
		for(int j=0; j < data.numNodes; j++){
			IloLinearNumExpr expr = cplex.linearNumExpr();
			int rhs = 0;
			//System.out.println("REGION "+j+" : ");
			for (int i = 0; i <data.numArcs; i++) {
				expr.addTerm(data.region[j][data.arcs[i][0]]*data.region[j][data.arcs[i][1]], u[i]);
				rhs += data.region[j][data.arcs[i][0]]*data.region[j][data.arcs[i][1]];
				//if(data.region[j][data.arcs[i][0]]*data.region[j][data.arcs[i][1]] == 1) {
					//System.out.println("   Arc "+i);
				//}
			}
			//System.out.println("rhs "+rhs);
			cplex.addLe(expr, rhs*(1-xbar[j]));
		}
	
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION: Maximize resource utilization by the given path	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i < data.numArcs; i++){
				obj.addTerm( ybar[i]*1*data.flowResource[i] , u[i]);
		}
		cplex.addMaximize(obj,"OBJ");
		cplex.solve();
		
		int originalResource = 0; //Original resource consumption
		for(int i=0; i < data.numArcs; i++){
			originalResource += ybar[i]*data.flowResource[i];
		}
		double addResource = round(cplex.getObjValue()); //Additional resource consumption 
		//System.out.println("Original: "+originalResource);
		//System.out.println("Additional: "+addResource);
		
		if(originalResource+addResource <= data.rBudget) {
			UB = LB;
			double resource = 0; // Resource consumption double check
			for(int i=0; i < data.numArcs; i++){
				resource += ybar[i]*data.flowResource[i]*(1+1*cplex.getValue(u[i]));
			}
			System.out.println("Current solution cannot be blocked: "+resource+" <= "+data.rBudget);
			
		}
		else {
			System.out.println("Constraint violation "+(originalResource+addResource)+" vs "+data.rBudget);
			// Add realization to the sample
			Realization s = new Realization(data); //to add to the sample
			for (int i = 0; i < data.numArcs; i++) {
				if(cplex.getValue(u[i]) > 0.00001) {s.u[i] = round(cplex.getValue(u[i]));}
			}
			s.computeGamma(data); 
			s.print(data);
			sample.add(s);
		}
	
		cplex.clearModel();
		cplex=null;
		System.gc();
	}






}
