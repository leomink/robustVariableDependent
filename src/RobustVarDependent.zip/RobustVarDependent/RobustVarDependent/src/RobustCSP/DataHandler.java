/**
 * This class holds all the data.
 * 
 */
package RobustCSP;

import ilog.concert.*;
import ilog.cplex.*;
import ilog.cplex.IloCplex.UnknownObjectException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import java.util.StringTokenizer;

import ilog.cplex.IloCplex;

public class DataHandler {
	// Name of the instance
	String CsvInput;
	// Random seed
	int seed;
	// Number of arcs
	int numArcs;
	// Number of nodes
	int numNodes;
	// Destinantion node
	int lastNode;
	// Source node
	int source;
	// All the arcs in the network stored in a vector where Arcs[i][0]= Tail for arc i and Arcs[i][1]= Head for arc i 
	int[][] arcs;
	// Cost per unit of flow for any arc i
	int[] flowCost;
	// Resource consumption per unit of flow for any arc i
	int[] flowResource;
	// Resource needed to attack an arc 
	int[] aWeight;
	// Resource available
	int rBudget;
	// Indicates which nodes belong to each region
	int[][] region;
	//Shortest path no failures
	int CSP;


	int mBudget; 	// Budget for maintenance
	int uBudget; 	// Budget for uncertainty

	public DataHandler(int s) {
		seed = s;
	}


	// This procedure reads data from a data file in DIMACS format
	public void ReadDimacs(String input) throws NumberFormatException, IOException {
		CsvInput = input;
		File file = new File(CsvInput);

		BufferedReader bufRdr = new BufferedReader(new FileReader(file));
		// Read first line
		String line = bufRdr.readLine();
		String[] array = line.split(" ");
		numNodes = Integer.parseInt(array[2]);
		numArcs = Integer.parseInt(array[3]);
		System.out.println("Nodes and Arcs "+numNodes+" "+numArcs);

		// Read Second line
		line = bufRdr.readLine();
		array = line.split(" ");
		source = Integer.parseInt(array[1]);

		// Read third line
		line = bufRdr.readLine();
		array = line.split(" ");
		lastNode = Integer.parseInt(array[1]);

		//System.out.println("WEPAAAA: "+source+" "+lastNode);

		arcs = new int[numArcs][2];
		flowCost = new int[numArcs];
		flowResource = new int[numArcs];

		String[] readed = new String[5];
		int row = 0;
		int col = 0;

		while ((line = bufRdr.readLine()) != null && row < numArcs + 3) {
			StringTokenizer st = new StringTokenizer(line, " ");
			while (st.hasMoreTokens()) {
				// get next token and store it in the array
				readed[col] = st.nextToken();
				col++;
			}

			if (row >= 0) {
				arcs[row][0] = (Integer.parseInt(readed[1]) );
				arcs[row][1] = (Integer.parseInt(readed[2]) );
				flowCost[row] = (Integer.parseInt(readed[3]) );
				flowResource[row] = (Integer.parseInt(readed[4]) );
			}

			col = 0;
			row++;

		}

	}


	public void genRandomInstance() {
		Random r = new Random(seed);
		region = new int[numNodes][numNodes];
		aWeight = new int[numArcs];
		
		for (int i = 0; i < numArcs; i++) {
			region[arcs[i][0]][arcs[i][0]] = 1;
			region[arcs[i][0]][arcs[i][1]] = 1;
			region[arcs[i][1]][arcs[i][0]] = 1;
			region[arcs[i][1]][arcs[i][1]] = 1;
			aWeight[i]=1+r.nextInt(9);
			//System.out.println(flowCost[i]+" "+flowResource[i]);
		}

	}


	public void PrintNetwork(String name) throws FileNotFoundException {
		// TODO Auto-generated method stub
		java.io.PrintStream ps = new java.io.PrintStream( new java.io.FileOutputStream("Grid"+name));

		ps.println("p sp "+numNodes+" "+numArcs);
		ps.println("n "+source+" "+"s");
		ps.println("n "+lastNode+" "+"t");

		for (int i = 0; i < numArcs; i++) {
			ps.println("a "+arcs[i][0]+" "+arcs[i][1]+" "+flowCost[i]+" "+flowResource[i]);
		}

	}


	public void setResourceBudget(double multiplier) throws IloException {
		IloCplex cplex = new IloCplex();
		cplex.setOut(null);

		//Create variables
		IloNumVar[] y = new IloNumVar[numArcs]; // Flow
		for (int i = 0; i < numArcs; i++) {
			y[i] = cplex.numVar(0, 1, IloNumVarType.Float, "y["+i+"]");
		}
		// Add flow constraints (but drop the last one)
		IloLinearNumExpr[] expr = new IloLinearNumExpr[numNodes];
		for (int n = 0; n < numNodes; n++) {
			expr[n] = cplex.linearNumExpr();
		}	
		for (int i = 0; i < numArcs; i++) {
			int tail = arcs[i][0];
			int head = arcs[i][1];
			expr[tail].addTerm(1, y[i]);
			expr[head].addTerm(-1, y[i]);
		}

		// Flow for the nodes (omit the sink!)
		for (int n = 0; n < numNodes; n++) {
			if(n!=source && n!=lastNode){cplex.addEq(expr[n], 0, "flow_"+0+"_"+n);}
		}
		// Flow for the source
		cplex.addEq(expr[source], 1);


		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i= 0; i < numArcs; i++){
			obj.addTerm(y[i], flowResource[i]);
		}	    	
		cplex.addMinimize(obj,"OBJ");

		// Optimize model
		cplex.solve();
		int	lb = (int) Math.round(cplex.getObjValue());
		cplex.getObjective().setSense(cplex.maximize().getSense());
		cplex.solve();
		int	ub = (int) Math.round(cplex.getObjValue());
		
		//Set resource budget
		//rBudget = (int) Math.round(lb+multiplier*(ub-lb));
		rBudget = (int) Math.round((multiplier)*(lb));
		System.out.println("Resource limits "+lb+" to "+ub+" rBudget: "+rBudget);
			
		cplex.clearModel();
		cplex=null;
		System.gc();


	}

	public void solveCSP() throws IloException {
		IloCplex cplex = new IloCplex();
		cplex.setOut(null);

		//Create variables
		IloNumVar[] y = new IloNumVar[numArcs]; // Flow
		for (int i = 0; i < numArcs; i++) {
			y[i] = cplex.numVar(0, 1, IloNumVarType.Float, "y["+i+"]");
		}
		// Add flow constraints (but drop the last one)
		IloLinearNumExpr[] expr = new IloLinearNumExpr[numNodes];
		for (int n = 0; n < numNodes; n++) {
			expr[n] = cplex.linearNumExpr();
		}	
		for (int i = 0; i < numArcs; i++) {
			int tail = arcs[i][0];
			int head = arcs[i][1];
			expr[tail].addTerm(1, y[i]);
			expr[head].addTerm(-1, y[i]);
		}

		// Flow for the nodes (omit the sink!)
		for (int n = 0; n < numNodes; n++) {
			if(n!=source && n!=lastNode){cplex.addEq(expr[n], 0, "flow_"+0+"_"+n);}
		}
		// Flow for the source
		cplex.addEq(expr[source], 1);

		//Resource constraint
		IloLinearNumExpr exprB = cplex.linearNumExpr();
		for (int i = 0; i < numArcs; i++) {
			exprB.addTerm(flowResource[i], y[i]);
		}
		cplex.addLe(exprB, rBudget);

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i= 0; i < numArcs; i++){
			obj.addTerm(y[i], flowCost[i]);
		}	    	
		cplex.addMinimize(obj,"OBJ");

		// Optimize model
		cplex.solve();
		CSP = (int) Math.round(cplex.getObjValue());
		System.out.println("Constrained Shortest Path "+CSP);
			
		cplex.clearModel();
		cplex=null;
		System.gc();


	}

	




}

