/**
 * This class holds all the logic and procedures for hitting a monkey in the face.
 * 
 * 
 */

package RobustVD;

import ilog.concert.*;
import ilog.cplex.*;
import ilog.cplex.IloCplex.UnknownObjectException;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Random;


public class AlgorithmHandler {

	int[] xstar; 								// Optimal solution
	int[] xbar; 								// Current solution
	int LB;
	int UB;
	ArrayList<Realization> sample;				// Current sample
	// Map avoid repeating samples
	HashMap<String, Integer> sMap;

	ArrayList<Integer>[] criticalPoints;		// Points to block realizations for each constraint
	IloCplex cplex;								// Cplex model
	int[] M;									// Big-M value for each constraint
	int[] U;									// Upper bound for leader influence on each constraint in the uncertainty set

	public AlgorithmHandler(DataHandler data) throws InterruptedException, IloException {
		LB = -999999999;
		UB = 0;						//Trivial x=0 solution is always feasible
		M = new int[data.nConsL] ;
		U = new int[data.nConsF] ;
		xstar = new int[data.nVar];
		xbar = new int[data.nVar];
		sample = new ArrayList<Realization>();
		criticalPoints = new ArrayList[data.nConsF];
		for (int j = 0; j < data.nConsF; j++) {
			criticalPoints[j] = new ArrayList<Integer>();
		}
		sMap = new HashMap<String, Integer>();

	}

	// Solves master with enhancements
	public void solveMasterE(DataHandler data, int timeLim) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.Param.TimeLimit, timeLim);
		cplex.setOut(null);

		//Define variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		ArrayList<IloNumVar>[] z = new ArrayList[data.nConsF]; //Binary for each critical point
		IloNumVar[] v = new IloNumVar[sample.size()]; //Binary for each sample
		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		for (int i = 0; i < data.nConsF; i++) {
			if(criticalPoints[i].size()>0) {
				z[i] = new ArrayList<IloNumVar>();
				for (int k = 0; k < criticalPoints[i].size(); k++) {
					IloNumVar aux = cplex.numVar(0, 1, IloNumVarType.Bool, "z"+i+","+k);
					z[i].add(aux);
				}			
			}
		}
		for (int h = 0; h < sample.size(); h++) {
			v[h] = cplex.numVar(0, 1, IloNumVarType.Float, "v["+h+"]");
		}

		// add constraints for each sample
		for (int h = 0; h < sample.size(); h++) {
			for(int j=0; j < data.nConsL; j++){
				IloLinearNumExpr expr1 = cplex.linearNumExpr();
				int uContribution = 0;
				for (int i = 0; i <data.nVar; i++) {
					expr1.addTerm(data.A[j][i], x[i]);
				}
				for (int i = 0; i <data.nParam; i++) {
					uContribution += data.B[j][i]*sample.get(h).u[i];
				}
				// Feasibility filter
				expr1.addTerm(-M[j], v[h]);
				cplex.addLe(expr1, data.b[j] - uContribution );
			}
		}

		// Feasibility filter II
		for (int h = 0; h < sample.size(); h++) {
			IloLinearNumExpr expr1 = cplex.linearNumExpr();
			expr1.addTerm(1, v[h]);
			for (int q = 0; q < data.nConsF; q++) {
				for (int k = 0; k < criticalPoints[q].size(); k++) {
					if(criticalPoints[q].get(k) >= sample.get(h).gamma[q]) {expr1.addTerm(-1, z[q].get(k));}
				}
			}
			cplex.addLe(expr1, 0);
		}		

		// Select at most one critical point per constraint in U
		for (int j = 0; j < data.nConsF; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < criticalPoints[j].size(); k++) {
				expr.addTerm(1,z[j].get(k));
			}
			cplex.addLe(expr, 1);
		}	
		// Critical points activation
		for (int j = 0; j < data.nConsF; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < criticalPoints[j].size(); k++) {
				expr.addTerm(criticalPoints[j].get(k),z[j].get(k));
			}
			for (int i = 0; i <data.nVar; i++) {
				expr.addTerm(-data.D[j][i], x[i]);
			}
			cplex.addLe(expr, 0);
		}	

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i<data.nVar; i++){
			obj.addTerm(x[i], data.c[i]);
		}

		cplex.addMinimize(obj,"OBJ");

		// Optimize model
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Problem is infeasible!");
			LB = UB;
		}
		else if(cplex.getStatus() == IloCplex.Status.Optimal) {
			xbar = new int[data.nVar];
			LB = (int) Math.round(cplex.getObjValue());
			//System.out.println("***********************************  CURRENT LB: "+ LB);
			for (int i = 0; i < data.nVar; i++) {
				if(cplex.getValue(x[i])>0.01) {xbar[i] = (int) Math.round(cplex.getValue(x[i]));}
			}
			// Print
			System.out.println("xbar: "+Arrays.toString(xbar));
			for (int q = 0; q < data.nConsF; q++) {
				for (int k = 0; k < criticalPoints[q].size(); k++) {
					if(cplex.getValue(z[q].get(k))>0.01) {System.out.println("v for constraint "+q+" for critical "+criticalPoints[q].get(k)+" = 1");}
				}
			}
		}
		else {
			System.out.println("ABORTED BECAUSE OF TIME LIMIT ");
		}
		cplex.clearModel();
		cplex=null;
		System.gc();
	}


	// Finds a realization to block xbar or determines it does not exist
	private void solveWorstCase(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setOut(null);

		//Uncertainty variables 
		IloNumVar[] u = new IloNumVar[data.nParam];
		//Block variables
		IloNumVar[] w = new IloNumVar[data.nConsL];

		for (int i = 0; i < data.nParam; i++) {
			u[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "u["+i+"]");
		}
		for (int j = 0; j < data.nConsL; j++) {
			w[j] = cplex.numVar(0, 1, IloNumVarType.Bool, "w["+j+"]");
		}

		// add constraints uncertainty set
		for(int j=0; j < data.nConsF; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			int xContribution = 0;
			for (int i = 0; i <data.nParam; i++) {
				exprf.addTerm(data.C[j][i], u[i]);
			}
			for (int i = 0; i <data.nVar; i++) {
				xContribution +=data.D[j][i]*xbar[i];
			}

			cplex.addLe(exprf, data.d[j]-xContribution);
		}

		// add constraints block
		for(int j=0; j < data.nConsL; j++){
			IloLinearNumExpr expr = cplex.linearNumExpr();
			int xContribution = 0;
			for (int i = 0; i <data.nVar; i++) {
				xContribution +=data.A[j][i]*xbar[i];
			}
			int blockPoint = data.b[j]-xContribution+1;
			expr.addTerm(blockPoint , w[j]);
			for (int i = 0; i <data.nParam; i++) {
				expr.addTerm(-data.B[j][i], u[i]);
			}

			cplex.addLe(expr, 0);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int j=0; j < data.nConsL; j++){
			obj.addTerm( 1 , w[j]);
		}
		cplex.addMaximize(obj,"OBJ");

		cplex.solve();
		if(Math.round(cplex.getObjValue()) == 0) {
			UB = LB;
			System.out.println("Current solution cannot be blocked!!!");
		}
		else {
			System.out.println("Constraints violated "+Math.round(cplex.getObjValue()));
			// Add realization to the sample
			Realization s = new Realization(data); //to add to the sample
			for (int i = 0; i < data.nParam; i++) {
				if(cplex.getValue(u[i]) > 0.01) {s.u[i] = (int) Math.round(cplex.getValue(u[i]));}
			}
			s.computeGamma(data, criticalPoints, U); //also updates the critical points
			s.print(data);
			sample.add(s);
		}

		cplex.clearModel();
		cplex=null;
		System.gc();

	}

	// gets an UB on the RHS
	public void getBigM(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setOut(null);

		//Leader and follower variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		IloNumVar[] u = new IloNumVar[data.nParam];

		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		for (int i = 0; i < data.nParam; i++) {
			u[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "u["+i+"]");
		}

		// add constraints leader
		for(int j=0; j < data.nConsL; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			for (int i = 0; i <data.nVar; i++) {
				exprf.addTerm(data.A[j][i], x[i]);
			}
			for (int i = 0; i <data.nParam; i++) {
				exprf.addTerm(data.B[j][i], u[i]);
			}
			cplex.addLe(exprf, data.b[j]);
		}

		// add constraints follower
		for(int j=0; j < data.nConsF; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			for (int i = 0; i <data.nParam; i++) {
				exprf.addTerm(data.C[j][i], u[i]);
			}
			for (int i = 0; i <data.nVar; i++) {
				exprf.addTerm(data.D[j][i], x[i]);
			}
			cplex.addLe(exprf, data.d[j]);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		cplex.addMaximize(obj,"OBJ");

		// Find limit on leader influence for each follower constraint
		for (int j = 0; j < data.nConsF; j++) {
			for(int i=0; i<data.nVar; i++){
				cplex.setLinearCoef(cplex.getObjective(), data.D[j][i], x[i]);
			}
			cplex.solve();
			U[j] = (int) Math.round(cplex.getObjValue());
			System.out.println("--------------------- U "+j+": "+U[j]);
		}


		// Optimize model for each constraint
		for (int j = 0; j < data.nConsL; j++) {
			Realization s = new Realization(data); //to add to the sample
			for(int i=0; i<data.nVar; i++){
				cplex.setLinearCoef(cplex.getObjective(), data.A[j][i], x[i]);
			}

			cplex.solve();
			M[j] = (int) Math.round(cplex.getObjValue());
			System.out.println("--------------------- Big M "+j+": "+M[j]);

			for (int i = 0; i < data.nParam; i++) {
				if(cplex.getValue(u[i])>0.01) {s.u[i] = (int) Math.round(cplex.getValue(u[i]));}
			}
			if(!sMap.containsKey(Arrays.toString(s.u))) {
				s.computeGamma(data, criticalPoints, U); //also updates the critical points
				s.print(data);
				sample.add(s);
				sMap.put(Arrays.toString(s.u), sample.size());
			}
		}


		cplex.clearModel();
		cplex=null;
		System.gc();
	}

	public void cuttingPlane(DataHandler data, double Atime, int timeLimit) throws IloException {

		int timeUsed = (int) ((System.currentTimeMillis()-Atime)/1000);
		getBigM(data);		// Get big Ms and initialize sample

		while(UB > LB && timeUsed < timeLimit) {
			solveMasterE(data, timeLimit-timeUsed);
			solveWorstCase(data);
			timeUsed = (int) ((System.currentTimeMillis()-Atime)/1000);
			int numCritical = 0;
			for (int j = 0; j < data.nConsF; j++) {
				numCritical+= criticalPoints[j].size();
			}
			data.numCritical = numCritical;
			System.out.println("************************************************** LB "+LB+" Sample Size: "+sample.size()+" Total Critical Points: "+numCritical);
		}

	}



}
