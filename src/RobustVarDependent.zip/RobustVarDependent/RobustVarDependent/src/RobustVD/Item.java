package RobustVD;

public class Item implements Comparable<Item>{

	int pos;
	int val;
	
	public Item(int p, int v) {
		pos = p;
		val = v;
	}
	
	@Override
	public int compareTo(Item a) {
		return -Integer.compare(val, a.val);
	}
	
}
