/**
 * This class holds all the data.
 * 
 */
package RobustVD;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Random;

public class DataHandler {
	// Number of variables Leader
	int nVar;
	
	// Number of uncertain parameters
	int nParam;
	
	// Number of constraints
	int nConsL;
	int nConsF;

	// Coefficients Leader
	int[][] A;
	int[][] B;

	// Coefficients Uncertainty
	int[][] C;
	int[][] D;

	// leader obj
	int[] c;

	// Leader RHS
	int[] b;

	// Follower RHS
	int[] d;

	// Seed for the random generator
	int seed;

	// RHS multiplier
	double rhsMult;

	//Number of critical points
	int numCritical;
	
	// Initialize empty
	public DataHandler(int n, int u, int m1, int m2) {
		nVar = n;
		nParam = u;
		nConsL = m1;
		nConsF = m2;
		A= new int[nConsL][nVar];
		B= new int[nConsL][nParam];
		C= new int[nConsF][nParam];
		D= new int[nConsF][nVar];
		c = new int[nVar];
		b = new int[nConsL];
		d = new int[nConsF];
		numCritical = 0; 
	}

	// General binary
	public void genRandomInstance(int s, double rhsMultiplier) {
		seed = s;
		rhsMult = rhsMultiplier;
		Random r = new Random(seed); 

		// Generate leader coefficients
		for(int j=0; j < nConsL; j++) {
			int sumA = 0;
			int sumB = 0;
			for (int i = 0; i < nVar; i++) {
				A[j][i] = 5*(0+r.nextInt(21));	//{0,10,...,50}
				sumA+=A[j][i];
			}
			for (int i = 0; i < nParam; i++) {
				B[j][i] = 5*(0+r.nextInt(21));	//{0,10,...,50}
				sumB+=B[j][i];
				if(sumB >= rhsMultiplier*sumA) {//Ensure feasibility
					B[j][i] = 0;
					i = nParam;
				}

			}

			b[j] = (int) Math.round(rhsMultiplier*sumA);
		}


		// Generate uncertainty set coefficients
		for(int j=0; j < nConsF; j++) {
			int sumC = 0;
			int sumD = 0;
			for (int i = 0; i < nParam; i++) {
				C[j][i]= 5*(0+r.nextInt(21));	//{0,10,...,50}
				sumC+=C[j][i];
			}			
			for (int i = 0; i < nVar; i++) {
				D[j][i]= 5*(0+r.nextInt(21));	//{0,10,...,50}
				sumD+=D[j][i];
				if(sumD >= rhsMultiplier*sumC) {//Ensure complete recourse
					D[j][i] = 0;
					i = nVar;
				}
			}

			d[j] = (int) Math.round(rhsMultiplier*sumC);
		}
		//Generate obj
		for (int i = 0; i < nVar; i++) {
			c[i]=-100+r.nextInt(51); 		//U[-100, -50]
		}

	}

	public void printInstance() {
		for (int j = 0; j < nConsL; j++) {
			System.out.println("A: "+Arrays.toString(A[j])+" <= "+b[j]);
		}
		for (int j = 0; j < nConsL; j++) {
			System.out.println("B: "+Arrays.toString(B[j]));
		}
		for (int j = 0; j < nConsF; j++) {
			System.out.println("C: "+Arrays.toString(C[j])+" <= "+d[j]);
		}
		for (int j = 0; j < nConsF; j++) {
			System.out.println("D: "+Arrays.toString(D[j]));
		}
		System.out.println("c: "+Arrays.toString(c));

	}

	void outputInstance() throws FileNotFoundException{
		int mult = (int) (rhsMult*100);
		String name=nVar+"_"+nParam+"_"+nConsL+"_"+mult+"_"+seed;
		java.io.PrintStream ps = new java.io.PrintStream( new java.io.FileOutputStream(name+".mps", false));
		ps.println("NAME"+" "+name);
		ps.println("ROWS");
		ps.println(" "+"N"+" "+"COST");
		for (int i = 0; i < nConsL; i++) {
			ps.println(" "+"L"+" "+"LK"+i);
		}
		for (int i = 0; i < nConsF; i++) {
			ps.println(" "+"L"+" "+"FK"+i);
		}
		for (int i = 0; i < nConsL; i++) {
			ps.println(" "+"L"+" "+"FKI"+i);	//Constraints to activate the indicator function
		}
		ps.println("COLUMNS");
		for (int i = 0; i <nVar; i++) {
			ps.println(" "+"X"+i+" "+"COST"+" "+(c[i])+"."); 
			for (int j = 0; j < nConsL; j++) {
				ps.println(" "+"X"+i+" "+"LK"+j+" "+A[j][i]+".");
			}
			for (int j = 0; j < nConsF; j++) {
				ps.println(" "+"X"+i+" "+"FK"+j+" "+D[j][i]+".");
			}
			for (int j = 0; j < nConsL; j++) {
				ps.println(" "+"X"+i+" "+"FKI"+j+" "+(-1*A[j][i])+".");
			}
		}
		for (int i = 0; i <nParam; i++) {
			for (int j = 0; j < nConsL; j++) {
				ps.println(" "+"Y"+i+" "+"LK"+j+" "+B[j][i]+".");
			}
			for (int j = 0; j < nConsF; j++) {
				ps.println(" "+"Y"+i+" "+"FK"+j+" "+C[j][i]+".");
			}
			for (int j = 0; j < nConsL; j++) {
				ps.println(" "+"Y"+i+" "+"FKI"+j+" "+(-1*B[j][i])+".");
			}
		}
		for (int j = 0; j <nConsL; j++) {
			ps.println(" "+"W"+j+" "+"FKI"+j+" "+(b[j]+1)+".");
		}
		ps.println("RHS");
		for (int j = 0; j < nConsL; j++) {
			ps.println(" "+"RHS"+" "+"LK"+j+" "+b[j]+".");
		}
		for (int j = 0; j < nConsF; j++) {
			ps.println(" "+"RHS"+" "+"FK"+j+" "+d[j]+".");
		}
		for (int j = 0; j < nConsL; j++) {
			ps.println(" "+"RHS"+" "+"FKI"+j+" "+0+".");
		}

		ps.println("BOUNDS");
		for (int i = 0; i <nVar; i++) {
			ps.println(" "+"UI BOUND"+"	"+"X"+i+"	"+1+".");
			ps.println(" "+"LI BOUND"+"	"+"X"+i+"	"+0+".");
		}
		for (int i = 0; i <nParam; i++) {
			ps.println(" "+"UI BOUND"+"	"+"Y"+i+"	"+1+".");
			ps.println(" "+"LI BOUND"+"	"+"Y"+i+"	"+0+".");
		}
		for (int j = 0; j <nConsL; j++) {
			ps.println(" "+"UI BOUND"+"	"+"W"+j+"	"+1+".");
			ps.println(" "+"LI BOUND"+"	"+"W"+j+"	"+0+".");
		}
		ps.println("ENDATA");

		//NOW THE AUX FILE ///////////////////////////////////////////////////////////////////////
		java.io.PrintStream aux = new java.io.PrintStream( new java.io.FileOutputStream(name+".aux", false));
		aux.println("N "+(nParam+nConsL));
		aux.println("M "+(nConsF+nConsL));
		for (int i = 0; i <nParam+nConsL; i++) {
			aux.println("LC "+(nVar+i));
		}
		for (int i = nConsL; i < (nConsL+nConsF+nConsL); i++) {
			aux.println("LR "+i);
		}
		for (int i = 0; i <nParam; i++) {
			aux.println("LO "+0);
		}
		for (int i = nParam; i <nParam+nConsL; i++) {
			aux.println("LO "+(-1));
		}
		
		aux.println("OS "+(1));

		System.out.println("DONE! "+name);

	}
	
	
	

}

