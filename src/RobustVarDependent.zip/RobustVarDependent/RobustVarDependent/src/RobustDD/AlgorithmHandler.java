/**
 * This class holds all the logic and procedures for hitting a monkey in the face.
 * 
 * 
 */

package RobustDD;

import ilog.concert.*;
import ilog.cplex.*;
import ilog.cplex.IloCplex.UnknownObjectException;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Random;

public class AlgorithmHandler {

	int[] xstar; 								// Optimal solution
	int[] xbar; 								// Current solution
	int LB;
	int UB;
	ArrayList<Realization> sample;				// Current sample
	// Map avoid repeating samples
	HashMap<String, Integer> sMap;

	ArrayList<Integer>[] criticalPoints;		// Points to block realizations for each constraint
	IloCplex cplex;								// Cplex model
	int[] M;									// Big-M value for each constraint
	int[] U;									// Upper bound for leader influence on each constraint in the uncertainty set

	// Array of DDs
	DecisionDiagram DD;						//One per follower constraint

	public AlgorithmHandler(DataHandler data) throws InterruptedException, IloException {
		LB = -999999999;
		UB = 0;						//Trivial x=0 solution is always feasible
		M = new int[data.nConsL] ;
		U = new int[data.nConsF] ;
		xstar = new int[data.nVar];
		xbar = new int[data.nVar];
		sample = new ArrayList<Realization>();
		criticalPoints = new ArrayList[data.nConsF];
		for (int j = 0; j < data.nConsF; j++) {
			criticalPoints[j] = new ArrayList<Integer>();
		}
		sMap = new HashMap<String, Integer>();

	}


	public void genDD(DataHandler data, int Q) throws IloException {

		//Run heuristic for variable ordering
		List<Integer> varOrder = new ArrayList<>();
		orderingHeuristic(varOrder,data);
		System.out.println("Variable Order: " + varOrder);

		//Initialize array
		DD = DecisionDiagram();
		DD = buildBDD(data, varOrder, Q);

	}

	private DecisionDiagram DecisionDiagram() {
		// TODO Auto-generated method stub
		return null;
	}


	private void orderingHeuristic(List<Integer> varOrder, DataHandler data) {
		List<Item> order=new ArrayList<>();
		// Compute sum of follower variables coefficients
		int[] sumVarCoef = new int[data.nParam];
		for (int i = 0; i < data.nParam; i++) {
			int sum = 0;
			for (int j = 0; j < data.nConsF; j++) {
				sum+=data.C[j][i];
				//sum+=data.B[j][i];
			}
			sumVarCoef[i] = sum;
		}
		for (int i = 0; i < data.nParam; i++) {
			order.add(new Item(i, sumVarCoef[i] ));
		}
		Collections.sort(order, Collections.reverseOrder());
		for (int i = 0; i < order.size(); i++) {
			varOrder.add(order.get(i).pos);
		}
	}

	// Builds exact DD for constraint k
	public DecisionDiagram buildBDD(DataHandler data, List<Integer> varOrder, int Q) throws IloException {
		int nodeCount = 0;

		DecisionDiagram dd = new DecisionDiagram();
		Queue<Node> currentLayerQueue = new ArrayDeque<>(); 	//Nodes being processed at some layer
		Queue<Node> nextLayerQueue = new ArrayDeque<>();    	//Nodes to be processed at layer+1

		// Create initial node
		Node root = new Node(data);
		root.ID = nodeCount;
		root.genKey(0);
		dd.GraphMap.put(root.key, root.ID);
		dd.nodes.add(root);
		currentLayerQueue.add(root); //Add it to the queue
		nodeCount++;

		// Create final node
		Node sink = new Node(data);
		sink.key = "END";
		sink.ID = nodeCount;
		dd.GraphMap.put(sink.key, sink.ID);
		dd.nodes.add(sink);
		dd.lastNode = nodeCount;
		nodeCount++;

		/////////// Build layer by layer ***********************************************************************************
		for (int layer = 0; layer < Q; layer++) {
			int varIndex = varOrder.get(layer);
			System.out.println("LAYER "+layer+" VAR "+varIndex+" QUEUE "+currentLayerQueue.size());
			//System.out.println("Completion Bounds follower: "+Arrays.toString(completionBounds));
			while(!currentLayerQueue.isEmpty())
			{
				Node node=currentLayerQueue.poll();

				// Create nodes from the parent
				Node noHead = node.createZeroNode();  
				Node yesHead = node.createOneNode(varIndex, data);

				////////////////////////////////////////// Try to add zero-arc 
				if(noHead.checkBounds(data)) {
					//Add node to the DD and to the queue for next layer
					noHead.ID = nodeCount;
					noHead.genKey(layer+1);
					// Check if the node has been created before
					if(dd.GraphMap.containsKey(noHead.key)==false) {
						dd.GraphMap.put(noHead.key, noHead.ID);
						dd.nodes.add(noHead);
						nextLayerQueue.add(noHead);
						nodeCount++;
					}
					// Create arc
					Arc noArc = new Arc(dd.GraphMap.get(node.key), dd.GraphMap.get(noHead.key), 0, varIndex);
					dd.arcs.add(noArc);                           
				}
				//////////////////////////////////////////// Try to add one-arc 
				if(yesHead.checkBounds(data)) {
					//Add node to the DD and to the queue for next layer
					yesHead.ID = nodeCount;
					yesHead.genKey(layer+1);
					// Check if the node has been created before
					if(dd.GraphMap.containsKey(yesHead.key)==false) {
						dd.GraphMap.put(yesHead.key, yesHead.ID);
						dd.nodes.add(yesHead);
						nextLayerQueue.add(yesHead);
						nodeCount++;
					}
					// Create arc
					Arc arc = new Arc(dd.GraphMap.get(node.key), dd.GraphMap.get(yesHead.key), 1, varIndex);
					dd.arcs.add(arc);                           
				}
			}

			currentLayerQueue=nextLayerQueue;
			nextLayerQueue=new ArrayDeque<>();
			System.gc();
		}
		// Add artificial zero arcs to the end node
		while( !currentLayerQueue.isEmpty() ){
			Node node=currentLayerQueue.poll();
			if(node.checkBoundsEND(data)) {
				Arc noArc = new Arc(dd.GraphMap.get(node.key), dd.GraphMap.get("END"), 0, -1);
				dd.arcs.add(noArc);
			}
		}
		for (int i = 0; i < dd.arcs.size(); i++) {
			Arc a = dd.arcs.get(i);
			dd.nodes.get(a.tail).out.add(a);
			dd.nodes.get(a.head).in.add(a);
		}
		dd.print3(data);

		return dd;
	}



	// Solves constrained version
	public void solveMasterPhaseOne(DataHandler data, int timeLim) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.Param.TimeLimit, timeLim);
		cplex.setOut(null);

		//Define variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		// add constraints for each sample
		for (int h = 0; h < sample.size(); h++) {
			for(int j=0; j < data.nConsL; j++){
				IloLinearNumExpr expr1 = cplex.linearNumExpr();
				int uContribution = 0;
				for (int i = 0; i <data.nVar; i++) {
					expr1.addTerm(data.A[j][i], x[i]);
				}
				for (int i = 0; i <data.nParam; i++) {
					uContribution += data.B[j][i]*sample.get(h).u[i];
				}
				cplex.addLe(expr1, data.b[j] - uContribution );
			}
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i<data.nVar; i++){
			obj.addTerm(x[i], data.c[i]);
		}

		cplex.addMinimize(obj,"OBJ");

		// Optimize model
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Problem phase one is infeasible!");
			LB = UB;
		}
		else if(cplex.getStatus() == IloCplex.Status.Optimal) {
			xbar = new int[data.nVar];
			LB = (int) Math.round(cplex.getObjValue());
			//System.out.println("***********************************  CURRENT LB: "+ LB);
			for (int i = 0; i < data.nVar; i++) {
				if(cplex.getValue(x[i])>0.01) {xbar[i] = (int) Math.round(cplex.getValue(x[i]));}
			}
			// Print
			System.out.println("xbar: "+Arrays.toString(xbar));
		}
		else {
			System.out.println("ABORTED BECAUSE OF TIME LIMIT ");
		}
		cplex.clearModel();
		cplex=null;
		System.gc();
	}

	// Solves constrained version
	public void solveMasterPhaseOneE(DataHandler data, int timeLim) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.Param.TimeLimit, timeLim);
		cplex.setOut(null);

		int limit = (int) Math.max(10, 1*data.nConsF);

		//Define variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		ArrayList<IloNumVar>[] z = new ArrayList[data.nConsF]; //Binary for each critical point
		IloNumVar[] v = new IloNumVar[sample.size()]; //Binary for each sample
		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		for (int i = 0; i < limit; i++) {
			if(criticalPoints[i].size()>0) {
				z[i] = new ArrayList<IloNumVar>();
				for (int k = 0; k < criticalPoints[i].size(); k++) {
					IloNumVar aux = cplex.numVar(0, 1, IloNumVarType.Bool, "z"+i+","+k);
					z[i].add(aux);
				}			
			}
		}
		for (int h = 0; h < sample.size(); h++) {
			v[h] = cplex.numVar(0, 1, IloNumVarType.Float, "v["+h+"]");
		}

		// add constraints for each sample
		for (int h = 0; h < sample.size(); h++) {
			for(int j=0; j < data.nConsL; j++){
				IloLinearNumExpr expr1 = cplex.linearNumExpr();
				int uContribution = 0;
				for (int i = 0; i <data.nVar; i++) {
					expr1.addTerm(data.A[j][i], x[i]);
				}
				for (int i = 0; i <data.nParam; i++) {
					uContribution += data.B[j][i]*sample.get(h).u[i];
				}
				// Feasibility filter
				expr1.addTerm(-M[j], v[h]);
				cplex.addLe(expr1, data.b[j] - uContribution );
			}
		}

		// Feasibility filter II
		for (int h = 0; h < sample.size(); h++) {
			IloLinearNumExpr expr1 = cplex.linearNumExpr();
			expr1.addTerm(1, v[h]);
			for (int q = 0; q < limit; q++) {
				for (int k = 0; k < criticalPoints[q].size(); k++) {
					if(criticalPoints[q].get(k) >= sample.get(h).gamma[q]) {expr1.addTerm(-1, z[q].get(k));}
				}
			}
			cplex.addLe(expr1, 0);
		}		

		// Select at most one critical point per constraint in U
		for (int j = 0; j < limit; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < criticalPoints[j].size(); k++) {
				expr.addTerm(1,z[j].get(k));
			}
			cplex.addLe(expr, 1);
		}	
		// Critical points activation
		for (int j = 0; j < limit; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < criticalPoints[j].size(); k++) {
				expr.addTerm(criticalPoints[j].get(k),z[j].get(k));
			}
			for (int i = 0; i <data.nVar; i++) {
				expr.addTerm(-data.D[j][i], x[i]);
			}
			cplex.addLe(expr, 0);
		}	


		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i<data.nVar; i++){
			obj.addTerm(x[i], data.c[i]);
		}

		cplex.addMinimize(obj,"OBJ");

		// Optimize model
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Problem phase one is infeasible!");
			LB = UB;
		}
		else if(cplex.getStatus() == IloCplex.Status.Optimal) {
			xbar = new int[data.nVar];
			LB = (int) Math.round(cplex.getObjValue());
			//System.out.println("***********************************  CURRENT LB: "+ LB);
			for (int i = 0; i < data.nVar; i++) {
				if(cplex.getValue(x[i])>0.01) {xbar[i] = (int) Math.round(cplex.getValue(x[i]));}
			}
			// Print
			System.out.println("xbar: "+Arrays.toString(xbar));
		}
		else {
			System.out.println("ABORTED BECAUSE OF TIME LIMIT ");
		}
		cplex.clearModel();
		cplex=null;
		System.gc();
	}


	// Solves high point relaxation
	public void solveMaster(DataHandler data, int timeLim) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.Param.TimeLimit, timeLim);
		cplex.setOut(null);

		//Define variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		ArrayList<IloNumVar>[] z = new ArrayList[data.nConsF]; //Binary for each critical point
		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		for (int i = 0; i < data.nConsF; i++) {
			if(criticalPoints[i].size()>0) {
				z[i] = new ArrayList<IloNumVar>();
				for (int k = 0; k < criticalPoints[i].size(); k++) {
					IloNumVar aux = cplex.numVar(0, 1, IloNumVarType.Bool, "v"+i+","+k);
					z[i].add(aux);
				}			
			}
		}

		// add constraints for each sample
		for (int h = 0; h < sample.size(); h++) {
			for(int j=0; j < data.nConsL; j++){
				IloLinearNumExpr expr1 = cplex.linearNumExpr();
				int uContribution = 0;
				for (int i = 0; i <data.nVar; i++) {
					expr1.addTerm(data.A[j][i], x[i]);
				}
				for (int i = 0; i <data.nParam; i++) {
					uContribution += data.B[j][i]*sample.get(h).u[i];
				}

				// Feasibility filter
				for (int q = 0; q < data.nConsF; q++) {
					for (int k = 0; k < criticalPoints[q].size(); k++) {
						if(criticalPoints[q].get(k) >= sample.get(h).gamma[q]) {expr1.addTerm(-M[j], z[q].get(k));}
					}
				}
				cplex.addLe(expr1, data.b[j] - uContribution );
			}
		}
		// Critical points activation
		for (int j = 0; j < data.nConsF; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < criticalPoints[j].size(); k++) {
				expr.addTerm(criticalPoints[j].get(k),z[j].get(k));
			}
			for (int i = 0; i <data.nVar; i++) {
				expr.addTerm(-data.D[j][i], x[i]);
			}
			cplex.addLe(expr, 0);
		}	

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i<data.nVar; i++){
			obj.addTerm(x[i], data.c[i]);
		}

		cplex.addMinimize(obj,"OBJ");

		// Optimize model
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Problem is infeasible!");
			LB = UB;
		}
		else if(cplex.getStatus() == IloCplex.Status.Optimal) {
			xbar = new int[data.nVar];
			LB = (int) Math.round(cplex.getObjValue());
			//System.out.println("***********************************  CURRENT LB: "+ LB);
			for (int i = 0; i < data.nVar; i++) {
				if(cplex.getValue(x[i])>0.01) {xbar[i] = (int) Math.round(cplex.getValue(x[i]));}
			}
			// Print
			System.out.println("xbar: "+Arrays.toString(xbar));
			for (int q = 0; q < data.nConsF; q++) {
				for (int k = 0; k < criticalPoints[q].size(); k++) {
					if(cplex.getValue(z[q].get(k))>0.01) {System.out.println("v for constraint "+q+" for critical "+criticalPoints[q].get(k)+" = 1");}
				}
			}
		}
		else {
			System.out.println("ABORTED BECAUSE OF TIME LIMIT ");
		}
		cplex.clearModel();
		cplex=null;
		System.gc();
	}

	// Solves master with enhancements
	public void solveMasterE(DataHandler data, int timeLim) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.Param.TimeLimit, timeLim);
		cplex.setOut(null);

		//Define variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		ArrayList<IloNumVar>[] z = new ArrayList[data.nConsF]; //Binary for each critical point
		IloNumVar[] v = new IloNumVar[sample.size()]; //Binary for each sample
		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		for (int i = 0; i < data.nConsF; i++) {
			if(criticalPoints[i].size()>0) {
				z[i] = new ArrayList<IloNumVar>();
				for (int k = 0; k < criticalPoints[i].size(); k++) {
					IloNumVar aux = cplex.numVar(0, 1, IloNumVarType.Bool, "z"+i+","+k);
					z[i].add(aux);
				}			
			}
		}
		for (int h = 0; h < sample.size(); h++) {
			v[h] = cplex.numVar(0, 1, IloNumVarType.Float, "v["+h+"]");
		}

		// add constraints for each sample
		for (int h = 0; h < sample.size(); h++) {
			for(int j=0; j < data.nConsL; j++){
				IloLinearNumExpr expr1 = cplex.linearNumExpr();
				int uContribution = 0;
				for (int i = 0; i <data.nVar; i++) {
					expr1.addTerm(data.A[j][i], x[i]);
				}
				for (int i = 0; i <data.nParam; i++) {
					uContribution += data.B[j][i]*sample.get(h).u[i];
				}
				// Feasibility filter
				expr1.addTerm(-M[j], v[h]);
				cplex.addLe(expr1, data.b[j] - uContribution );
			}
		}

		// Feasibility filter II
		for (int h = 0; h < sample.size(); h++) {
			IloLinearNumExpr expr1 = cplex.linearNumExpr();
			expr1.addTerm(1, v[h]);
			for (int q = 0; q < data.nConsF; q++) {
				for (int k = 0; k < criticalPoints[q].size(); k++) {
					if(criticalPoints[q].get(k) >= sample.get(h).gamma[q]) {expr1.addTerm(-1, z[q].get(k));}
				}
			}
			cplex.addLe(expr1, 0);
		}		

		// Select at most one critical point per constraint in U
		for (int j = 0; j < data.nConsF; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < criticalPoints[j].size(); k++) {
				expr.addTerm(1,z[j].get(k));
			}
			cplex.addLe(expr, 1);
		}	
		// Critical points activation
		for (int j = 0; j < data.nConsF; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < criticalPoints[j].size(); k++) {
				expr.addTerm(criticalPoints[j].get(k),z[j].get(k));
			}
			for (int i = 0; i <data.nVar; i++) {
				expr.addTerm(-data.D[j][i], x[i]);
			}
			cplex.addLe(expr, 0);
		}	

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i<data.nVar; i++){
			obj.addTerm(x[i], data.c[i]);
		}

		cplex.addMinimize(obj,"OBJ");

		// Optimize model
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Problem is infeasible!");
			LB = UB;
		}
		else if(cplex.getStatus() == IloCplex.Status.Optimal) {
			xbar = new int[data.nVar];
			LB = (int) Math.round(cplex.getObjValue());
			//System.out.println("***********************************  CURRENT LB: "+ LB);
			for (int i = 0; i < data.nVar; i++) {
				if(cplex.getValue(x[i])>0.01) {xbar[i] = (int) Math.round(cplex.getValue(x[i]));}
			}
			// Print
			System.out.println("xbar: "+Arrays.toString(xbar));
			for (int q = 0; q < data.nConsF; q++) {
				for (int k = 0; k < criticalPoints[q].size(); k++) {
					if(cplex.getValue(z[q].get(k))>0.01) {System.out.println("v for constraint "+q+" for critical "+criticalPoints[q].get(k)+" = 1");}
				}
			}
		}
		else {
			System.out.println("ABORTED BECAUSE OF TIME LIMIT ");
		}
		cplex.clearModel();
		cplex=null;
		System.gc();
	}


	// Finds a realization to block xbar or determines it does not exist
	private void solveWorstCase(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setOut(null);

		//Uncertainty variables 
		IloNumVar[] u = new IloNumVar[data.nParam];
		//Block variables
		IloNumVar[] w = new IloNumVar[data.nConsL];

		for (int i = 0; i < data.nParam; i++) {
			u[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "u["+i+"]");
		}
		for (int j = 0; j < data.nConsL; j++) {
			w[j] = cplex.numVar(0, 1, IloNumVarType.Bool, "w["+j+"]");
		}

		// add constraints uncertainty set
		for(int j=0; j < data.nConsF; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			int xContribution = 0;
			for (int i = 0; i <data.nParam; i++) {
				exprf.addTerm(data.C[j][i], u[i]);
			}
			for (int i = 0; i <data.nVar; i++) {
				xContribution +=data.D[j][i]*xbar[i];
			}

			cplex.addLe(exprf, data.d[j]-xContribution);
		}

		// add constraints block
		for(int j=0; j < data.nConsL; j++){
			IloLinearNumExpr expr = cplex.linearNumExpr();
			int xContribution = 0;
			for (int i = 0; i <data.nVar; i++) {
				xContribution +=data.A[j][i]*xbar[i];
			}
			int blockPoint = data.b[j]-xContribution+1;
			expr.addTerm(blockPoint , w[j]);
			for (int i = 0; i <data.nParam; i++) {
				expr.addTerm(-data.B[j][i], u[i]);
			}

			cplex.addLe(expr, 0);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int j=0; j < data.nConsL; j++){
			obj.addTerm( 1 , w[j]);
		}
		cplex.addMaximize(obj,"OBJ");

		cplex.solve();
		if(Math.round(cplex.getObjValue()) == 0) {
			UB = LB;
			System.out.println("Current solution cannot be blocked!!!");
		}
		else {
			System.out.println("Constraints violated "+Math.round(cplex.getObjValue()));
			// Add realization to the sample
			Realization s = new Realization(data); //to add to the sample
			for (int i = 0; i < data.nParam; i++) {
				if(cplex.getValue(u[i]) > 0.01) {s.u[i] = (int) Math.round(cplex.getValue(u[i]));}
			}
			s.computeGamma(data, criticalPoints, U); //also updates the critical points
			s.print(data);
			sample.add(s);
		}

		cplex.clearModel();
		cplex=null;
		System.gc();

	}

	// gets an UB on the RHS
	public void getBigM(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setOut(null);

		//Leader and follower variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		IloNumVar[] u = new IloNumVar[data.nParam];

		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		for (int i = 0; i < data.nParam; i++) {
			u[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "u["+i+"]");
		}

		// add constraints leader
		for(int j=0; j < data.nConsL; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			for (int i = 0; i <data.nVar; i++) {
				exprf.addTerm(data.A[j][i], x[i]);
			}
			for (int i = 0; i <data.nParam; i++) {
				exprf.addTerm(data.B[j][i], u[i]);
			}
			cplex.addLe(exprf, data.b[j]);
		}

		// add constraints follower
		for(int j=0; j < data.nConsF; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			for (int i = 0; i <data.nParam; i++) {
				exprf.addTerm(data.C[j][i], u[i]);
			}
			for (int i = 0; i <data.nVar; i++) {
				exprf.addTerm(data.D[j][i], x[i]);
			}
			cplex.addLe(exprf, data.d[j]);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		cplex.addMaximize(obj,"OBJ");

		// Find limit on leader influence for each follower constraint
		for (int j = 0; j < data.nConsF; j++) {
			for(int i=0; i<data.nVar; i++){
				cplex.setLinearCoef(cplex.getObjective(), data.D[j][i], x[i]);
			}
			cplex.solve();
			U[j] = (int) Math.round(cplex.getObjValue());
			System.out.println("--------------------- U "+j+": "+U[j]);
		}


		// Optimize model for each constraint
		for (int j = 0; j < data.nConsL; j++) {
			Realization s = new Realization(data); //to add to the sample
			for(int i=0; i<data.nVar; i++){
				cplex.setLinearCoef(cplex.getObjective(), data.A[j][i], x[i]);
			}

			cplex.solve();
			M[j] = (int) Math.round(cplex.getObjValue());
			System.out.println("--------------------- Big M "+j+": "+M[j]);
		}


		cplex.clearModel();
		cplex=null;
		System.gc();
	}
	
	public void getBigMDD(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setOut(null);

		//Leader and follower variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		IloNumVar[] u = new IloNumVar[data.nParam];

		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		for (int i = 0; i < data.nParam; i++) {
			u[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "u["+i+"]");
		}

		// add constraints leader
		for(int j=0; j < data.nConsL; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			for (int i = 0; i <data.nVar; i++) {
				exprf.addTerm(data.A[j][i], x[i]);
			}
			for (int i = 0; i <data.nParam; i++) {
				exprf.addTerm(data.B[j][i], u[i]);
			}
			cplex.addLe(exprf, data.b[j]);
		}

		// add constraints follower
		for(int j=0; j < data.nConsF; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			for (int i = 0; i <data.nParam; i++) {
				exprf.addTerm(data.C[j][i], u[i]);
			}
			for (int i = 0; i <data.nVar; i++) {
				exprf.addTerm(data.D[j][i], x[i]);
			}
			cplex.addLe(exprf, data.d[j]);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		cplex.addMaximize(obj,"OBJ");

		// Find limit on leader influence for each follower constraint
		for (int j = 0; j < data.nConsF; j++) {
			for(int i=0; i<data.nVar; i++){
				cplex.setLinearCoef(cplex.getObjective(), data.D[j][i], x[i]);
			}
			cplex.solve();
			U[j] = (int) Math.round(cplex.getObjValue());
			System.out.println("--------------------- U "+j+": "+U[j]);
		}


		// Optimize model for each constraint
		for (int j = 0; j < data.nConsL; j++) {
			for(int i=0; i<data.nVar; i++){
				cplex.setLinearCoef(cplex.getObjective(), 0, x[i]);
			}
			for(int i=0; i<data.nParam; i++){
				cplex.setLinearCoef(cplex.getObjective(), data.B[j][i], u[i]);
			}
			cplex.solve();
			M[j] = (int) Math.round(cplex.getObjValue());
			System.out.println("--------------------- Big M "+j+": "+M[j]);
		}


		cplex.clearModel();
		cplex=null;
		System.gc();
	}


	public void cuttingPlane(DataHandler data, double Atime, int timeLimit) throws IloException {

		int timeUsed = (int) ((System.currentTimeMillis()-Atime)/1000);
		getBigM(data);		// Get big Ms and initialize sample

		while(UB > LB && timeUsed < timeLimit) {
			solveMasterE(data, timeLimit-timeUsed);
			solveWorstCase(data);
			timeUsed = (int) ((System.currentTimeMillis()-Atime)/1000);
			int numCritical = 0;
			for (int j = 0; j < data.nConsF; j++) {
				numCritical+= criticalPoints[j].size();
			}
			data.numCritical = numCritical;
			System.out.println("************************************************** LB "+LB+" Sample Size: "+sample.size()+" Total Critical Points: "+numCritical);
		}

	}

	public void twoPhase(DataHandler data, double Atime, int timeLimit) throws IloException {
		int timeUsed = (int) ((System.currentTimeMillis()-Atime)/1000);
		getBigM(data);				// Get big Ms and initialize sample
		//getUnblockable(data);		// Try to find unblockable realizations

		// Phase 1: no blocking allowed
		while(UB > LB && timeUsed < timeLimit) {
			solveMasterPhaseOne(data, timeLimit-timeUsed);
			solveWorstCase(data);
			timeUsed = (int) ((System.currentTimeMillis()-Atime)/1000);
			int numCritical = 0;
			for (int j = 0; j < data.nConsF; j++) {
				numCritical+= criticalPoints[j].size();
			}
			data.numCritical = numCritical;
			System.out.println("************************************************** PHASE ONE LB "+LB+" Sample Size: "+sample.size()+" Total Critical Points: "+numCritical);
		} 
		// Go for phase two!
		setupPhaseTwo(data, 1);

		while(UB > LB && timeUsed < timeLimit) {
			solveMasterE(data, timeLimit-timeUsed);
			solveWorstCase(data);
			timeUsed = (int) ((System.currentTimeMillis()-Atime)/1000);
			int numCritical = 0;
			for (int j = 0; j < data.nConsF; j++) {
				numCritical+= criticalPoints[j].size();
			}
			data.numCritical = numCritical;
			System.out.println("************************************************** PHASE TWO LB "+LB+" UB "+UB+" Sample Size: "+sample.size()+" Total Critical Points: "+numCritical);
		}


	}

	private void setupPhaseTwo(DataHandler data, int K) {
		// Reset LB
		LB = -999999999;

		// Keep the last K realizations discovered
		ArrayList<Realization> aux = new ArrayList<Realization>();
		for (int i = sample.size()-1; i > Math.max(0,sample.size()-1-K) ; i--) {
			aux.add(sample.get(i));
			//System.out.println("KEEPING REALIZATION "+i);
		}

		sample.clear();
		sMap.clear();
		criticalPoints = new ArrayList[data.nConsF];
		for (int j = 0; j < data.nConsF; j++) {
			criticalPoints[j] = new ArrayList<Integer>();
		}

		for (int i = 0; i < aux.size(); i++) {
			if(!sMap.containsKey(Arrays.toString(aux.get(i).u))) {
				aux.get(i).computeGamma(data, criticalPoints, U); //also updates the critical points
				//aux.get(i).print(data);
				sample.add(aux.get(i));
				sMap.put(Arrays.toString(aux.get(i).u), sample.size());
			}
		}


	}

	// Try to get realizations that are too difficult to block
	private void getUnblockable(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setOut(null);

		//Leader and follower variables 
		IloNumVar[] u = new IloNumVar[data.nParam];
		for (int i = 0; i < data.nParam; i++) {
			u[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "u["+i+"]");
		}

		// add constraints uncertainty set
		for(int j=0; j < data.nConsF; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			int xContribution = (int) (0.5*U[j]);
			for (int i = 0; i <data.nParam; i++) {
				exprf.addTerm(data.C[j][i], u[i]);
			}
			cplex.addLe(exprf, data.d[j]-xContribution);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		cplex.addMaximize(obj,"OBJ");

		// Optimize realization contribution for each leader constraint
		for (int j = 0; j < data.nConsL; j++) {
			Realization s = new Realization(data); //to add to the sample
			for(int i=0; i<data.nVar; i++){
				cplex.setLinearCoef(cplex.getObjective(), data.B[j][i], u[i]);
			}

			cplex.solve();
			System.out.println("--------------------- Unblockable contribution "+": "+(int) Math.round(cplex.getObjValue()));

			for (int i = 0; i < data.nParam; i++) {
				if(cplex.getValue(u[i])>0.01) {s.u[i] = (int) Math.round(cplex.getValue(u[i]));}
			}
			if(!sMap.containsKey(Arrays.toString(s.u))) {
				s.computeGamma(data, criticalPoints, U); //also updates the critical points
				s.print(data);
				sample.add(s);
				sMap.put(Arrays.toString(s.u), sample.size());
			}

		}

		cplex.clearModel();
		cplex=null;
		System.gc();


	}

	public void singleLevelDD(DataHandler data, int timeLim) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.Param.TimeLimit, timeLim);
		//Leader and follower variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		// Flow variables for the DDs
		IloNumVar[][] y = new IloNumVar[DD.arcs.size()][data.nConsL]; //flow for each arc, each DD, and each leader constraint 
		for (int a = 0; a < DD.arcs.size(); a++) {
			for(int j=0; j < data.nConsL; j++){
				if(DD.arcs.get(a).varIndex==-1) {y[a][j] = cplex.numVar(0, 1, IloNumVarType.Float);}
				else {y[a][j] = cplex.numVar(0, 1, IloNumVarType.Float);}
			}
		}
		// Dual variables
		IloNumVar[][] pi = new IloNumVar[DD.nodes.size()][data.nConsL];
		for(int j=0; j < data.nConsL; j++){
			for (int i = 0; i < DD.nodes.size(); i++) {
				pi[i][j] = cplex.numVar(-999999, 999999, IloNumVarType.Float);
			}
			pi[DD.lastNode][j] = cplex.numVar(0,0, IloNumVarType.Float); // Set dual at sink to 0
		}
		IloNumVar[][] lambda = new IloNumVar[DD.arcs.size()][data.nConsL]; 
		for (int a = 0; a < DD.arcs.size(); a++) {
			for(int j=0; j < data.nConsL; j++){
				if(DD.arcs.get(a).varIndex==-1) {
					lambda[a][j] = cplex.numVar(0, M[j]+1, IloNumVarType.Float); //+1 for numerical issues
				}
			}
		}
		// Indicator variables
		IloNumVar[] v = new IloNumVar[DD.nodes.get(DD.lastNode).in.size()]; //For each arc in last layer
		for (int q = 0; q < DD.nodes.get(DD.lastNode).in.size(); q++) { //Number of incoming arcs to terminal!
			v[q] = cplex.numVar(0, 1, IloNumVarType.Float);
		}
		ArrayList<IloNumVar>[] z = new ArrayList[data.nConsF]; //Binary for each critical point
		getCriticalPoints(data);
		for (int i = 0; i < data.nConsF; i++) {
			if(criticalPoints[i].size()>0) {
				z[i] = new ArrayList<IloNumVar>();
				for (int k = 0; k < criticalPoints[i].size(); k++) {
					IloNumVar aux = cplex.numVar(0, 1, IloNumVarType.Bool);
					z[i].add(aux);
				}			
			}
		}
		// add constraints leader
		for(int j=0; j < data.nConsL; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			for (int i = 0; i <data.nVar; i++) {
				exprf.addTerm(data.A[j][i], x[i]);
			}
			for (int a = 0; a < DD.arcs.size(); a++) {
				if(DD.arcs.get(a).arcVal == 1) {exprf.addTerm(data.B[j][DD.arcs.get(a).varIndex], y[a][j]);}
			}
			cplex.addLe(exprf, data.b[j]);
		}

		// FLOW CONSTRAINTS: Add flow constraints (but drop the last one)
		for(int j=0; j < data.nConsL; j++){
			IloLinearNumExpr[] expr = new IloLinearNumExpr[DD.nodes.size()];
			for (int n = 0; n < DD.nodes.size(); n++) {
				expr[n] = cplex.linearNumExpr();
			}	
			for (int i = 0; i < DD.arcs.size(); i++) {
				int tail = DD.arcs.get(i).tail;
				int head = DD.arcs.get(i).head;
				expr[tail].addTerm(1, y[i][j]);
				expr[head].addTerm(-1, y[i][j]);	
			}
			cplex.addEq(expr[0], 1, "c0");
			for (int n = 1; n < DD.nodes.size(); n++) {
				if(n != DD.lastNode){cplex.addEq(expr[n], 0, "flow_"+0+"_"+n);}
			}
		}
		//Add arc capacity constraints
		for(int j=0; j < data.nConsL; j++){
			int count = 0;
			for (int a = 0; a < DD.arcs.size(); a++) {
				// For end arcs only
				if(DD.arcs.get(a).varIndex==-1) {	
					IloLinearNumExpr exprA = cplex.linearNumExpr();
					exprA.addTerm(1, y[a][j]);
					exprA.addTerm(1, v[count]);
					cplex.addLe(exprA, 1);
					count++;
				}
			}
		}
		// Dual feasibility
		for(int j=0; j < data.nConsL; j++){
			for (int a = 0; a < DD.arcs.size(); a++) {
				int tail = DD.arcs.get(a).tail;
				int head = DD.arcs.get(a).head;
				if(DD.arcs.get(a).varIndex>=0) {//All arcs except the last layer
					IloLinearNumExpr exprA = cplex.linearNumExpr();
					exprA.addTerm(1, pi[tail][j]);
					exprA.addTerm(-1, pi[head][j]);
					if(DD.arcs.get(a).arcVal == 1) {cplex.addGe(exprA, data.B[j][DD.arcs.get(a).varIndex]);}
					else {cplex.addGe(exprA, 0);}
				}
				else {//Last layer arcs
					IloLinearNumExpr exprA = cplex.linearNumExpr();
					exprA.addTerm(1, pi[tail][j]);
					exprA.addTerm(-1, pi[head][j]);
					exprA.addTerm(1, lambda[a][j]);
					cplex.addGe(exprA, 0);
				}

			}
		}
		// Complementary slackness: primal objective = dual objective 
		for(int j=0; j < data.nConsL; j++){
			IloLinearNumExpr exprB = cplex.linearNumExpr();
			for (int a = 0; a < DD.arcs.size(); a++) {
				if(DD.arcs.get(a).arcVal == 1){exprB.addTerm(data.B[j][DD.arcs.get(a).varIndex], y[a][j]);}
			}
			exprB.addTerm(-1, pi[0][j]);
			cplex.addEq(exprB, 0);
		}
		// Dual activation constraints
		for(int j=0; j < data.nConsL; j++){
			int count = 0;
			for (int a = 0; a < DD.arcs.size(); a++) {
				if(DD.arcs.get(a).varIndex == -1) {//Last layer arcs
					IloLinearNumExpr exprA = cplex.linearNumExpr();
					exprA.addTerm(1, lambda[a][j]);
					exprA.addTerm(-M[j], v[count]);
					cplex.addLe(exprA, 0.00001);
					count++;
				}
			}
		}
		
		// Critical points activation
		for (int j = 0; j < data.nConsF; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < criticalPoints[j].size(); k++) {
				expr.addTerm(criticalPoints[j].get(k),z[j].get(k));
			}
			for (int i = 0; i <data.nVar; i++) {
				expr.addTerm(-data.D[j][i], x[i]);
			}
			cplex.addLe(expr, 0);
		}
		// Feasibility filter II
		for (int u = 0; u < DD.nodes.get(DD.lastNode).in.size(); u++) { //Number of incoming arcs to terminal!
			Arc a = DD.nodes.get(DD.lastNode).in.get(u);
			Node n = DD.nodes.get(a.tail);
			IloLinearNumExpr expr1 = cplex.linearNumExpr();
			expr1.addTerm(1, v[u]);
			for (int q = 0; q < data.nConsF; q++) {
				for (int k = 0; k < criticalPoints[q].size(); k++) {
					if(criticalPoints[q].get(k) >= data.d[q]-n.S[q]+1) {expr1.addTerm(-1, z[q].get(k));}
				}
			}
			cplex.addLe(expr1, 0);
		}
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i<data.nVar; i++){
			obj.addTerm(x[i], data.c[i]);
		}

		cplex.addMinimize(obj,"OBJ");

		// Optimize model
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		DD Model is infeasible!");
		}
		else if(cplex.getStatus() == IloCplex.Status.Optimal) {
			UB = (int) Math.round(cplex.getObjValue());
			LB = UB;
			System.out.println("***********************************  DD Model Obj: "+ LB);
			xstar = new int[data.nVar];
			System.out.println("x:");
			for (int i = 0; i < data.nVar; i++) {
				if(cplex.getValue(x[i])>0.1) {System.out.print(i+" "); xstar[i]=1;}
			}
			System.out.println();
			//System.out.println("w:");
			//for (int i = 0; i < DD.arcs.size(); i++) {
			//if(cplex.getValue(w[i])>0.1)System.out.println("Index:"+DD.arcs.get(i).varIndex+" Cost: "+DD.arcs.get(i).cost+" Leader? "+DD.arcs.get(i).leaderVar);
			//if(DD.arcs.get(i).arcVal==0 && DD.arcs.get(i).leaderVar && cplex.getValue(lambda[i])>0.0001)System.out.println("Lambda: "+cplex.getValue(lambda[i])+" X VALUE: "+cplex.getValue(x[DD.arcs.get(i).varIndex]));
			//if(DD.arcs.get(i).arcVal==1 && DD.arcs.get(i).leaderVar && cplex.getValue(beta[i])>0.0001)System.out.println("Beta: "+cplex.getValue(beta[i])+" X VALUE: "+cplex.getValue(x[DD.arcs.get(i).varIndex]));
			//}

			for(int j=0; j < data.nConsL; j++){
				System.out.println("PI_"+0+"_"+(j+1)+": "+cplex.getValue(pi[0][j]));
				for (int a = 0; a < DD.arcs.size(); a++) {
					if(DD.arcs.get(a).varIndex==-1 && cplex.getValue(lambda[a][j]) > 0.0001) {
						//System.out.println("Lambda_"+a+"_"+(j+1)+": "+cplex.getValue(lambda[a][j]));
					}
				}
			}
			for (int i = 0; i < v.length; i++) {
				if(cplex.getValue(v[i]) > 0.0001) {System.out.print("v_"+i+" ");}
			}
			System.out.println();

		}
		else {
			System.out.println("ABORTED BECAUSE OF TIME LIMIT ");
			LB = (int) cplex.getBestObjValue(); 
			if (cplex.getStatus() == IloCplex.Status.Feasible) {UB = (int) cplex.getObjValue();}
		}
		cplex.clearModel();
		cplex=null;
		System.gc();

	}

	public void singleLevelDDR(DataHandler data, int timeLim) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.Param.TimeLimit, timeLim);
		//Leader and follower variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		// Dual variables
		IloNumVar[][] pi = new IloNumVar[DD.nodes.size()][data.nConsL];
		for(int j=0; j < data.nConsL; j++){
			for (int i = 0; i < DD.nodes.size(); i++) {
				pi[i][j] = cplex.numVar(-999999, 999999, IloNumVarType.Float);
			}
			pi[DD.lastNode][j] = cplex.numVar(0,0, IloNumVarType.Float); // Set dual at sink to 0
		}
		IloNumVar[][] lambda = new IloNumVar[DD.arcs.size()][data.nConsL]; 
		for (int a = 0; a < DD.arcs.size(); a++) {
			for(int j=0; j < data.nConsL; j++){
				if(DD.arcs.get(a).varIndex==-1) {
					lambda[a][j] = cplex.numVar(0, M[j]+1, IloNumVarType.Float); //+1 for numerical issues
				}
			}
		}
		// Indicator variables
		IloNumVar[] v = new IloNumVar[DD.nodes.get(DD.lastNode).in.size()]; //For each arc in last layer
		for (int q = 0; q < DD.nodes.get(DD.lastNode).in.size(); q++) { //Number of incoming arcs to terminal!
			v[q] = cplex.numVar(0, 1, IloNumVarType.Float);
		}
		ArrayList<IloNumVar>[] z = new ArrayList[data.nConsF]; //Binary for each critical point
		getCriticalPoints(data);
		for (int i = 0; i < data.nConsF; i++) {
			if(criticalPoints[i].size()>0) {
				z[i] = new ArrayList<IloNumVar>();
				for (int k = 0; k < criticalPoints[i].size(); k++) {
					IloNumVar aux = cplex.numVar(0, 1, IloNumVarType.Bool);
					z[i].add(aux);
				}			
			}
		}
		// add constraints leader
		for(int j=0; j < data.nConsL; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			for (int i = 0; i <data.nVar; i++) {
				exprf.addTerm(data.A[j][i], x[i]);
			}
			exprf.addTerm(1, pi[0][j]);
			cplex.addLe(exprf, data.b[j]);
		}

		// Dual feasibility
		for(int j=0; j < data.nConsL; j++){
			for (int a = 0; a < DD.arcs.size(); a++) {
				int tail = DD.arcs.get(a).tail;
				int head = DD.arcs.get(a).head;
				if(DD.arcs.get(a).varIndex>=0) {//All arcs except the last layer
					IloLinearNumExpr exprA = cplex.linearNumExpr();
					exprA.addTerm(1, pi[tail][j]);
					exprA.addTerm(-1, pi[head][j]);
					if(DD.arcs.get(a).arcVal == 1) {cplex.addGe(exprA, data.B[j][DD.arcs.get(a).varIndex]);}
					else {cplex.addGe(exprA, 0);}
				}
				else {//Last layer arcs
					IloLinearNumExpr exprA = cplex.linearNumExpr();
					exprA.addTerm(1, pi[tail][j]);
					exprA.addTerm(-1, pi[head][j]);
					exprA.addTerm(1, lambda[a][j]);
					cplex.addGe(exprA, 0);
				}

			}
		}
		// Dual linearization constraints
		for(int j=0; j < data.nConsL; j++){
			int count = 0;
			for (int a = 0; a < DD.arcs.size(); a++) {
				if(DD.arcs.get(a).varIndex == -1) {//Last layer arcs
					IloLinearNumExpr exprA = cplex.linearNumExpr();
					exprA.addTerm(1, lambda[a][j]);
					exprA.addTerm(-M[j], v[count]);
					cplex.addLe(exprA, 0.00001);
					count++;
				}
			}
		}
		// Critical points activation
		for (int j = 0; j < data.nConsF; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < criticalPoints[j].size(); k++) {
				expr.addTerm(criticalPoints[j].get(k),z[j].get(k));
			}
			for (int i = 0; i <data.nVar; i++) {
				expr.addTerm(-data.D[j][i], x[i]);
			}
			cplex.addLe(expr, 0);
		}
		// Feasibility filter II
		for (int u = 0; u < DD.nodes.get(DD.lastNode).in.size(); u++) { //Number of incoming arcs to terminal!
			Arc a = DD.nodes.get(DD.lastNode).in.get(u);
			Node n = DD.nodes.get(a.tail);
			IloLinearNumExpr expr1 = cplex.linearNumExpr();
			expr1.addTerm(1, v[u]);
			for (int q = 0; q < data.nConsF; q++) {
				for (int k = 0; k < criticalPoints[q].size(); k++) {
					if(criticalPoints[q].get(k) >= data.d[q]-n.S[q]+1) {expr1.addTerm(-1, z[q].get(k));}
				}
			}
			cplex.addLe(expr1, 0);
		}
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i<data.nVar; i++){
			obj.addTerm(x[i], data.c[i]);
		}

		cplex.addMinimize(obj,"OBJ");

		// Optimize model
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		DD Model is infeasible!");
		}
		else if(cplex.getStatus() == IloCplex.Status.Optimal) {
			UB = (int) Math.round(cplex.getObjValue());
			LB = UB;
			System.out.println("***********************************  DD Model Obj: "+ LB);
			xstar = new int[data.nVar];
			System.out.println("x:");
			for (int i = 0; i < data.nVar; i++) {
				if(cplex.getValue(x[i])>0.1) {System.out.print(i+" "); xstar[i]=1;}
			}
			System.out.println();
			//System.out.println("w:");
			//for (int i = 0; i < DD.arcs.size(); i++) {
			//if(cplex.getValue(w[i])>0.1)System.out.println("Index:"+DD.arcs.get(i).varIndex+" Cost: "+DD.arcs.get(i).cost+" Leader? "+DD.arcs.get(i).leaderVar);
			//if(DD.arcs.get(i).arcVal==0 && DD.arcs.get(i).leaderVar && cplex.getValue(lambda[i])>0.0001)System.out.println("Lambda: "+cplex.getValue(lambda[i])+" X VALUE: "+cplex.getValue(x[DD.arcs.get(i).varIndex]));
			//if(DD.arcs.get(i).arcVal==1 && DD.arcs.get(i).leaderVar && cplex.getValue(beta[i])>0.0001)System.out.println("Beta: "+cplex.getValue(beta[i])+" X VALUE: "+cplex.getValue(x[DD.arcs.get(i).varIndex]));
			//}

			for(int j=0; j < data.nConsL; j++){
				System.out.println("PI_"+0+"_"+(j+1)+": "+cplex.getValue(pi[0][j]));
				for (int a = 0; a < DD.arcs.size(); a++) {
					if(DD.arcs.get(a).varIndex==-1 && cplex.getValue(lambda[a][j]) > 0.0001) {
						//System.out.println("Lambda_"+a+"_"+(j+1)+": "+cplex.getValue(lambda[a][j]));
					}
				}
			}
			for (int i = 0; i < v.length; i++) {
				if(cplex.getValue(v[i]) > 0.0001) {System.out.print("v_"+i+" ");}
			}
			System.out.println();

		}
		else {
			System.out.println("ABORTED BECAUSE OF TIME LIMIT ");
			LB = (int) cplex.getBestObjValue(); 
			if (cplex.getStatus() == IloCplex.Status.Feasible) {UB = (int) cplex.getObjValue();}
		}
		cplex.clearModel();
		cplex=null;
		System.gc();

	}

	

	private void getCriticalPoints(DataHandler data) {
		// Extract from each node in the last layer
		for (int q = 0; q < DD.nodes.get(DD.lastNode).in.size(); q++) { //Number of incoming arcs to terminal!
			Arc a = DD.nodes.get(DD.lastNode).in.get(q);
			Node n = DD.nodes.get(a.tail);
			for(int j=0; j < data.nConsF; j++){
				int cPoint = data.d[j]-n.S[j]+1;
				if(!criticalPoints[j].contains(cPoint)) {
					if(cPoint <= U[j]) {
						criticalPoints[j].add(cPoint);
						//System.out.println("CRITICAL POINT ADDED FOR CONSTRAINT "+j+" : "+cPoint);
					}
				}
			}
		}
		
	}

}
