package RobustDD;

import java.util.ArrayList;

public class Arc {
	int ID; 		//Position in the arc array
	int tail;
	int head;
	int arcVal;
	int varIndex;
	String key;
	
	public Arc(int _tail, int _head, int _arcVal, int _varIndex){
		key="";
		tail = _tail;
		head = _head;
		arcVal = _arcVal;
		varIndex = _varIndex;
	}

	public String getKey(DecisionDiagram bdd) {
		key = bdd.nodes.get(tail).key+" -> "+bdd.nodes.get(head).key;
		return key;
	}
	

	public void print() {
		
		System.out.println(key);
				
	}
	
	
}
