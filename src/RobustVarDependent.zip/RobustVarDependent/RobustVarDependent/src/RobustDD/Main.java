/**
 * This is the main class for the algorithm.
 * 
 * 
 */
package RobustDD;

import ilog.concert.IloException;

import java.awt.DefaultFocusTraversalPolicy;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Random;


public class Main {

	public static void main(String[] args) throws IOException, InterruptedException, IloException {

		java.io.PrintStream ps = new java.io.PrintStream( new java.io.FileOutputStream("ResultsDD.txt", true));

		double[] RHSMult = {0.5, 1};
		int[] nVars = {15};
		int[] nConst = {1};

		for (int j = 0; j < nVars.length; j++) {
			for (int i = 0; i < nConst.length; i++) {
				for (int b = 0; b < RHSMult.length ; b++) {
					for (int seed = 1; seed <= 10; seed++) {

						// Generate instance
						DataHandler data = new DataHandler(nVars[j], nVars[j], nConst[i], nConst[i]);
						data.genRandomInstance(seed, RHSMult[b]); //Seed, RHS
						data.printInstance();
						data.outputInstance();

						// Begin the time count						
						double Atime = System.currentTimeMillis();
						int timeLimit = 1800;

						runDD(data, Atime, timeLimit, ps);

					}
				}
			}
		}
	}


	private static void runCuttingPlane(DataHandler data, double Atime, int timeLimit, PrintStream ps) throws InterruptedException, IloException {
		// Create an AlgorithmHandler
		AlgorithmHandler alg = new AlgorithmHandler(data);
		alg.cuttingPlane(data, Atime, timeLimit);

		System.out.println("Solved "+(System.currentTimeMillis()-Atime)/1000+" "+alg.LB+" "+alg.UB);
		ps.println("CutPlane "+data.nVar+" "+data.nParam+" "+data.nConsL+" "+data.nConsF+" "+data.rhsMult+" "+data.seed+" "+(System.currentTimeMillis()-Atime)/1000+" "+alg.LB+" "+alg.UB+" "+alg.sample.size()+" "+alg.sample.size()*data.nConsF+" "+data.numCritical);
	}

	private static void runDD(DataHandler data, double Atime, int timeLimit, PrintStream ps) throws InterruptedException, IloException {
		// Create an AlgorithmHandler
		AlgorithmHandler alg = new AlgorithmHandler(data);
		alg.genDD(data, data.nParam);
		alg.getBigMDD(data);
		alg.singleLevelDDR(data, timeLimit);

		System.out.println("Solved "+(System.currentTimeMillis()-Atime)/1000+" "+alg.LB+" "+alg.UB);
		ps.println("DD "+data.nVar+" "+data.nParam+" "+data.nConsL+" "+data.nConsF+" "+data.rhsMult+" "+data.seed+" "+(System.currentTimeMillis()-Atime)/1000+" "+alg.LB+" "+alg.UB+" "+alg.DD.nodes.size()+" "+alg.DD.arcs.size());
	}


}
