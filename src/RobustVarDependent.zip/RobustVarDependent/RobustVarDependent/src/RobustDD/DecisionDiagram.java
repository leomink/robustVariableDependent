package RobustDD;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import ilog.concert.IloNumVar;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;


public class DecisionDiagram {

	ArrayList<Node> nodes;
	ArrayList<Arc> arcs;
	int lastNode; //Points to the index of the last node in the nodes array
	List<Integer> varOrder;

	// Map containing the nodes already created
	Hashtable<String, Integer> GraphMap;
	int numNodes;
	int numArcs;

	public DecisionDiagram() {
		nodes = new ArrayList<Node>();
		arcs = new ArrayList<Arc>();
		GraphMap = new Hashtable<String, Integer>();
		numNodes = 0;
		numArcs = 0;
	}

	public void print(DataHandler data) {

		System.out.println("***************************DP GRAPH*****************************************************************");
		System.out.println(" NODES: "+nodes.size()+" arcs: "+arcs.size());
		for (int i = 0; i < nodes.size(); i++) {
			System.out.println("Node "+i+": "+nodes.get(i).key);
			for (int j = 0; j < nodes.get(i).out.size(); j++) {
				String head = nodes.get(nodes.get(i).out.get(j).head).key;
				System.out.print("      arc "+nodes.get(i).out.get(j).arcVal+": "+head);
			}
			System.out.println();

		}
	}

	public void print3(DataHandler data) {
		System.out.println(" NODES: "+nodes.size()+" arcs: "+arcs.size());
/*
		for (int i = 0; i < arcs.size(); i++) {
			if(arcs.get(i).varIndex == -1)System.out.println("ARC "+i+" from "+arcs.get(i).tail+" to "+arcs.get(i).head+" arc val: "+arcs.get(i).arcVal+" varIndex: "+arcs.get(i).varIndex );
		}
*/		 
	}


	public void clearInOut() {
		for (int i = 0; i < nodes.size(); i++) {
			nodes.get(i).in.clear();
			nodes.get(i).out.clear();
		}

	}

	public void removeOutArcs(int nodeIndex) {

		for (int i = 0; i < nodes.get(nodeIndex).out.size(); i++) {
			Arc a = nodes.get(nodeIndex).out.get(i);
			nodes.get(a.head).in.remove(a); //Remove from destination
			arcs.remove(a);	//Remove from arc list
		}
		nodes.get(nodeIndex).out.clear(); //Remove from origin

	}



}
