package RobustDD;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class Node {

	String key;             //String representation
	int ID;                 //Position in the DD nodes array
	ArrayList<Arc> out;     //Arcs going out
	ArrayList<Arc> in;      //Arcs coming in
	int layer;

	// State: current LHS for constraint k
	int S[];

	//Constructor for new node
	public Node(DataHandler data) {
		key = "";
		ID = -1;
		S = new int[data.nConsF];
		out = new ArrayList<Arc>();
		in = new ArrayList<Arc>();
		layer = 0;
	}
	//Constructor for new node as a copy of other node
	Node(Node node) {
		key = "";
		out = new ArrayList<>();
		in = new ArrayList<>();
		S = new int[node.S.length];
		for (int j = 0; j < S.length; j++) {
			S[j] = node.S[j];	
		}

	}

	public Node createZeroNode() {
		Node node = new Node(this); // State after a zero arc stays the same!!!
		return node;
	}

	public Node createOneNode(int i, DataHandler data) {
		Node node = new Node(this);
		// Update the state after one arc for follower variable i
		for (int j = 0; j < S.length; j++) {
			node.S[j]+=data.C[j][i];
		}
		return node;
	}


	public void genKey(int _layer) {
		layer = _layer;
		key = Arrays.toString(S);
		key += " Layer: "+layer;
	}

	public void print() {
		System.out.println(key);
		System.out.println();
	}

	public boolean checkBounds(DataHandler data) {
		// Check follower constraint
		for (int j = 0; j < S.length; j++) {
			if(S[j] > data.d[j]) {
				return false;
			}
		}
		return true;
	}
	public boolean checkBoundsEND(DataHandler data) {
		// Check each one of the follower constraints
		for (int j = 0; j < S.length; j++) {
			if(S[j] > data.d[j]) {
				System.out.println("THIS SHOULD NEVER HAPPEN!!!!!!!!!!!!!!!!!!!!!!!! "+S);
				return false;
			}
		}
		return true;
	}


}

