/**
 * This class holds all the logic and procedures for hitting a monkey in the face.
 * 
 * 
 */

package RobustSensitivityExp;

import ilog.concert.*;
import ilog.cplex.*;
import ilog.cplex.IloCplex.UnknownObjectException;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Random;


public class AlgorithmHandler {

	int[] xstar; 								// Optimal solution
	int[] xbar; 								// Current solution
	int LB;
	int UB;
	ArrayList<Realization> sample;				// Current sample
	// Map avoid repeating samples
	HashMap<String, Integer> sMap;

	ArrayList<Integer>[] criticalPoints;		// Points to block realizations for each constraint
	IloCplex cplex;								// Cplex model
	int[] M;									// Big-M value for each constraint
	int[] U;									// Upper bound for leader influence on each constraint in the uncertainty set

	double timeMasterE;
	double timeMasterB;
	double timeMasterCP;

	double timeSubProblem;

	int numMasterSolved;
	int numSubSolved;
	int numVarsMasterE;
	int numConstMasterE;
	int numVarsMasterB;
	int numConstMasterB;
	int numVarsMasterCP;
	int numConstMasterCP;

	public AlgorithmHandler(DataHandler data) throws InterruptedException, IloException {
		LB = -999999999;
		UB = 0;						//Trivial x=0 solution is always feasible
		M = new int[data.nConsL] ;
		U = new int[data.nConsF] ;
		xstar = new int[data.nVar];
		xbar = new int[data.nVar];
		sample = new ArrayList<Realization>();
		criticalPoints = new ArrayList[data.nConsF];
		for (int j = 0; j < data.nConsF; j++) {
			criticalPoints[j] = new ArrayList<Integer>();
		}
		sMap = new HashMap<String, Integer>();

		timeMasterE = 0;
		numVarsMasterE = 0;
		numConstMasterE = 0;
		
		timeMasterB = 0;
		numVarsMasterB = 0;
		numConstMasterB = 0;
		
		timeMasterCP = 0;
		numVarsMasterCP = 0;
		numConstMasterCP = 0;
		
		numMasterSolved = 0;
		numSubSolved = 0;
		timeSubProblem = 0;

	}

	private void orderingHeuristic(List<Integer> varOrder, DataHandler data) {
		List<Item> order=new ArrayList<>();
		// Compute sum of follower variables coefficients
		int[] sumVarCoef = new int[data.nVar];
		for (int i = 0; i < data.nVar; i++) {
			int sum = 0;
			for (int j = 0; j < data.nConsF; j++) {
				sum+=data.B[j][i];
				sum+=data.C[j][i];
			}
			sumVarCoef[i] = sum;
		}
		for (int i = 0; i < data.nVar; i++) {
			order.add(new Item(i, sumVarCoef[i] ));
		}
		Collections.sort(order);
		for (int i = 0; i < order.size(); i++) {
			varOrder.add(order.get(i).pos);
		}

		// Compute sum of leader coefficients
		sumVarCoef = new int[data.nVar];
		order.clear();
		for (int i = 0; i < data.nVar; i++) {
			int sum = 0;
			for (int j = 0; j < data.nConsL; j++) {
				sum+=data.A[j][i];
				sum+=data.D[j][i];
			}
			sumVarCoef[i] = sum;
		}
		for (int i = 0; i < data.nVar; i++) {
			order.add(new Item(i, sumVarCoef[i] ));
		}
		Collections.sort(order);
		for (int i = 0; i < order.size(); i++) {
			varOrder.add(order.get(i).pos);
		}


	}

	// Solves master with NO enhancements, No critical points
	public void solveMasterBasic(DataHandler data, int timeLim) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.Param.TimeLimit, timeLim);
		cplex.setOut(null);
		// Turn off preprocessing
		cplex.setParam(IloCplex.Param.Preprocessing.Presolve, false);
		cplex.setParam(IloCplex.Param.Threads, 1);
		
		double Atime = System.currentTimeMillis();

		//Define variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		IloNumVar[][] y = new IloNumVar[data.nConsF][sample.size()]; //Binary for each constraint and sample
		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		for (int i = 0; i < data.nConsF; i++) {
			for (int k = 0; k < sample.size(); k++) {
				y[i][k] = cplex.numVar(0, 1, IloNumVarType.Bool, "y"+i+","+k);
			}			
		}

		// add constraints for each sample
		for (int h = 0; h < sample.size(); h++) {
			for(int j=0; j < data.nConsL; j++){
				IloLinearNumExpr expr1 = cplex.linearNumExpr();
				int uContribution = 0;
				for (int i = 0; i <data.nVar; i++) {
					expr1.addTerm(data.A[j][i], x[i]);
				}
				for (int i = 0; i <data.nParam; i++) {
					uContribution += data.B[j][i]*sample.get(h).u[i];
				}
				// Feasibility filter
				for(int q=0; q < data.nConsF; q++){
					expr1.addTerm(-M[j], y[q][h]);
				}
				
				cplex.addLe(expr1, data.b[j] - uContribution );
			}
		}

		// Critical points activation
		for (int j = 0; j < data.nConsF; j++) {
			for (int h = 0; h < sample.size(); h++) {
				IloLinearNumExpr expr = cplex.linearNumExpr();
				expr.addTerm(sample.get(h).gamma[j], y[j][h]);
				for (int i = 0; i <data.nVar; i++) {
					expr.addTerm(-data.D[j][i], x[i]);
				}
				cplex.addLe(expr, 0);
			}
		}	

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i<data.nVar; i++){
			obj.addTerm(x[i], data.c[i]);
		}

		cplex.addMinimize(obj,"OBJ");

		// Optimize model
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Problem is infeasible!");
			LB = UB;
		}
		else if(cplex.getStatus() == IloCplex.Status.Optimal) {
			xbar = new int[data.nVar];
			LB = (int) Math.round(cplex.getObjValue());
			//System.out.println("***********************************  CURRENT LB: "+ LB);
			for (int i = 0; i < data.nVar; i++) {
				if(cplex.getValue(x[i])>0.01) {xbar[i] = (int) Math.round(cplex.getValue(x[i]));}
			}
			// Print
			System.out.println("xbar: "+Arrays.toString(xbar));
			for (int q = 0; q < data.nConsF; q++) {
				for (int h = 0; h < sample.size(); h++) {
					if(cplex.getValue(y[q][h])>0.01) {System.out.println("y for constraint "+q+" for point "+h+" = 1");}
				}
			}
		}
		else {
			System.out.println("ABORTED BECAUSE OF TIME LIMIT ");
		}

		double solTime = (System.currentTimeMillis()-Atime)/1000;
		timeMasterB+=solTime;
		numVarsMasterB = cplex.getNcols();
		numConstMasterB =  cplex.getNrows();

		cplex.clearModel();
		cplex=null;
		System.gc();
	}

	// Solves master with the critical points formulation
	public void solveMasterCP(DataHandler data, int timeLim) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.Param.TimeLimit, timeLim);
		cplex.setOut(null);
		// Turn off preprocessing
		cplex.setParam(IloCplex.Param.Preprocessing.Presolve, false);
		cplex.setParam(IloCplex.Param.Threads, 1);
		
		double Atime = System.currentTimeMillis();
	
		//Define variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		ArrayList<IloNumVar>[] z = new ArrayList[data.nConsF]; //Binary for each critical point
		
		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		for (int i = 0; i < data.nConsF; i++) {
			if(criticalPoints[i].size()>0) {
				z[i] = new ArrayList<IloNumVar>();
				for (int k = 0; k < criticalPoints[i].size(); k++) {
					IloNumVar aux = cplex.numVar(0, 1, IloNumVarType.Bool, "z"+i+","+k);
					z[i].add(aux);
				}			
			}
		}
	
		// add constraints for each sample
		for (int h = 0; h < sample.size(); h++) {
			for(int j=0; j < data.nConsL; j++){
				IloLinearNumExpr expr1 = cplex.linearNumExpr();
				int uContribution = 0;
				for (int i = 0; i <data.nVar; i++) {
					expr1.addTerm(data.A[j][i], x[i]);
				}
				for (int i = 0; i <data.nParam; i++) {
					uContribution += data.B[j][i]*sample.get(h).u[i];
				}
				// Feasibility filter
				for (int q = 0; q < data.nConsF; q++) {
					for (int k = 0; k < criticalPoints[q].size(); k++) {
						if(criticalPoints[q].get(k) >= sample.get(h).gamma[q]) {expr1.addTerm(-M[j], z[q].get(k));}
					}
				}
				cplex.addLe(expr1, data.b[j] - uContribution );
			}
		}

		// Critical points activation
		for (int j = 0; j < data.nConsF; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < criticalPoints[j].size(); k++) {
				expr.addTerm(criticalPoints[j].get(k),z[j].get(k));
			}
			for (int i = 0; i <data.nVar; i++) {
				expr.addTerm(-data.D[j][i], x[i]);
			}
			cplex.addLe(expr, 0);
		}	
	
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i<data.nVar; i++){
			obj.addTerm(x[i], data.c[i]);
		}
	
		cplex.addMinimize(obj,"OBJ");
	
		// Optimize model
		cplex.solve();
	
		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Problem is infeasible!");
			LB = UB;
		}
		else if(cplex.getStatus() == IloCplex.Status.Optimal) {
			xbar = new int[data.nVar];
			LB = (int) Math.round(cplex.getObjValue());
			//System.out.println("***********************************  CURRENT LB: "+ LB);
			for (int i = 0; i < data.nVar; i++) {
				if(cplex.getValue(x[i])>0.01) {xbar[i] = (int) Math.round(cplex.getValue(x[i]));}
			}
			// Print
			System.out.println("xbar: "+Arrays.toString(xbar));
			for (int q = 0; q < data.nConsF; q++) {
				for (int k = 0; k < criticalPoints[q].size(); k++) {
					if(cplex.getValue(z[q].get(k))>0.01) {System.out.println("v for constraint "+q+" for critical "+criticalPoints[q].get(k)+" = 1");}
				}
			}
		}
		else {
			System.out.println("ABORTED BECAUSE OF TIME LIMIT ");
		}
	
		double solTime = (System.currentTimeMillis()-Atime)/1000;
		timeMasterCP+=solTime;
		numVarsMasterCP = cplex.getNcols();
		numConstMasterCP =  cplex.getNrows();
	
		cplex.clearModel();
		cplex=null;
		System.gc();
	}

	// Solves master with all enhancements
	public void solveMasterE(DataHandler data, int timeLim) throws IloException {
		cplex = new IloCplex();
		cplex.setParam(IloCplex.Param.TimeLimit, timeLim);
		cplex.setOut(null);
		// Turn off preprocessing
		cplex.setParam(IloCplex.Param.Preprocessing.Presolve, false);
		cplex.setParam(IloCplex.Param.Threads, 1);
		
		double Atime = System.currentTimeMillis();

		//Define variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		ArrayList<IloNumVar>[] z = new ArrayList[data.nConsF]; //Binary for each critical point
		IloNumVar[] v = new IloNumVar[sample.size()]; //Binary for each sample
		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		for (int i = 0; i < data.nConsF; i++) {
			if(criticalPoints[i].size()>0) {
				z[i] = new ArrayList<IloNumVar>();
				for (int k = 0; k < criticalPoints[i].size(); k++) {
					IloNumVar aux = cplex.numVar(0, 1, IloNumVarType.Bool, "z"+i+","+k);
					z[i].add(aux);
				}			
			}
		}
		for (int h = 0; h < sample.size(); h++) {
			v[h] = cplex.numVar(0, 1, IloNumVarType.Float, "v["+h+"]");
		}

		// add constraints for each sample
		for (int h = 0; h < sample.size(); h++) {
			for(int j=0; j < data.nConsL; j++){
				IloLinearNumExpr expr1 = cplex.linearNumExpr();
				int uContribution = 0;
				for (int i = 0; i <data.nVar; i++) {
					expr1.addTerm(data.A[j][i], x[i]);
				}
				for (int i = 0; i <data.nParam; i++) {
					uContribution += data.B[j][i]*sample.get(h).u[i];
				}
				// Feasibility filter
				expr1.addTerm(-M[j], v[h]);
				cplex.addLe(expr1, data.b[j] - uContribution );
			}
		}

		// Feasibility filter II
		for (int h = 0; h < sample.size(); h++) {
			IloLinearNumExpr expr1 = cplex.linearNumExpr();
			expr1.addTerm(1, v[h]);
			for (int q = 0; q < data.nConsF; q++) {
				for (int k = 0; k < criticalPoints[q].size(); k++) {
					if(criticalPoints[q].get(k) >= sample.get(h).gamma[q]) {expr1.addTerm(-1, z[q].get(k));}
				}
			}
			cplex.addLe(expr1, 0);
		}		

		// Select at most one critical point per constraint in U
		for (int j = 0; j < data.nConsF; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < criticalPoints[j].size(); k++) {
				expr.addTerm(1,z[j].get(k));
			}
			cplex.addLe(expr, 1);
		}	
		// Critical points activation
		for (int j = 0; j < data.nConsF; j++) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int k = 0; k < criticalPoints[j].size(); k++) {
				expr.addTerm(criticalPoints[j].get(k),z[j].get(k));
			}
			for (int i = 0; i <data.nVar; i++) {
				expr.addTerm(-data.D[j][i], x[i]);
			}
			cplex.addLe(expr, 0);
		}	

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int i=0; i<data.nVar; i++){
			obj.addTerm(x[i], data.c[i]);
		}

		cplex.addMinimize(obj,"OBJ");

		// Optimize model
		cplex.solve();

		if(cplex.getStatus() == IloCplex.Status.Infeasible || cplex.getStatus() == IloCplex.Status.InfeasibleOrUnbounded){
			System.out.println("		Problem is infeasible!");
			LB = UB;
		}
		else if(cplex.getStatus() == IloCplex.Status.Optimal) {
			xbar = new int[data.nVar];
			LB = (int) Math.round(cplex.getObjValue());
			//System.out.println("***********************************  CURRENT LB: "+ LB);
			for (int i = 0; i < data.nVar; i++) {
				if(cplex.getValue(x[i])>0.01) {xbar[i] = (int) Math.round(cplex.getValue(x[i]));}
			}
			// Print
			System.out.println("xbar: "+Arrays.toString(xbar));
			for (int q = 0; q < data.nConsF; q++) {
				for (int k = 0; k < criticalPoints[q].size(); k++) {
					if(cplex.getValue(z[q].get(k))>0.01) {System.out.println("v for constraint "+q+" for critical "+criticalPoints[q].get(k)+" = 1");}
				}
			}
		}
		else {
			System.out.println("ABORTED BECAUSE OF TIME LIMIT ");
		}

		double solTime = (System.currentTimeMillis()-Atime)/1000;
		timeMasterE+=solTime;
		numVarsMasterE = cplex.getNcols();
		numConstMasterE =  cplex.getNrows();

		cplex.clearModel();
		cplex=null;
		System.gc();
	}


	// Finds a realization to block xbar or determines it does not exist
	private void solveWorstCase(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setOut(null);
		double Atime = System.currentTimeMillis();

		//Uncertainty variables 
		IloNumVar[] u = new IloNumVar[data.nParam];
		//Block variables
		IloNumVar[] w = new IloNumVar[data.nConsL];

		for (int i = 0; i < data.nParam; i++) {
			u[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "u["+i+"]");
		}
		for (int j = 0; j < data.nConsL; j++) {
			w[j] = cplex.numVar(0, 1, IloNumVarType.Bool, "w["+j+"]");
		}

		// add constraints uncertainty set
		for(int j=0; j < data.nConsF; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			int xContribution = 0;
			for (int i = 0; i <data.nParam; i++) {
				exprf.addTerm(data.C[j][i], u[i]);
			}
			for (int i = 0; i <data.nVar; i++) {
				xContribution +=data.D[j][i]*xbar[i];
			}

			cplex.addLe(exprf, data.d[j]-xContribution);
		}

		// add constraints block
		for(int j=0; j < data.nConsL; j++){
			IloLinearNumExpr expr = cplex.linearNumExpr();
			int xContribution = 0;
			for (int i = 0; i <data.nVar; i++) {
				xContribution +=data.A[j][i]*xbar[i];
			}
			int blockPoint = data.b[j]-xContribution+1;
			expr.addTerm(blockPoint , w[j]);
			for (int i = 0; i <data.nParam; i++) {
				expr.addTerm(-data.B[j][i], u[i]);
			}

			cplex.addLe(expr, 0);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		for(int j=0; j < data.nConsL; j++){
			obj.addTerm( 1 , w[j]);
		}
		cplex.addMaximize(obj,"OBJ");

		cplex.solve();
		if(Math.round(cplex.getObjValue()) == 0) {
			UB = LB;
			System.out.println("Current solution cannot be blocked!!!");
		}
		else {
			System.out.println("Constraints violated "+Math.round(cplex.getObjValue()));
			// Add realization to the sample
			Realization s = new Realization(data); //to add to the sample
			for (int i = 0; i < data.nParam; i++) {
				if(cplex.getValue(u[i]) > 0.01) {s.u[i] = (int) Math.round(cplex.getValue(u[i]));}
			}
			s.computeGamma(data, criticalPoints, U); //also updates the critical points
			s.print(data);
			sample.add(s);
		}

		double solTime = (System.currentTimeMillis()-Atime)/1000;
		timeSubProblem+=solTime;

		cplex.clearModel();
		cplex=null;
		System.gc();

	}

	// gets an UB on the RHS
	public void getBigM(DataHandler data) throws IloException {
		cplex = new IloCplex();
		cplex.setOut(null);

		//Leader and follower variables 
		IloNumVar[] x = new IloNumVar[data.nVar];
		IloNumVar[] u = new IloNumVar[data.nParam];

		for (int i = 0; i < data.nVar; i++) {
			x[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "x["+i+"]");
		}
		for (int i = 0; i < data.nParam; i++) {
			u[i] = cplex.numVar(0, 1, IloNumVarType.Bool, "u["+i+"]");
		}

		// add constraints leader
		for(int j=0; j < data.nConsL; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			for (int i = 0; i <data.nVar; i++) {
				exprf.addTerm(data.A[j][i], x[i]);
			}
			for (int i = 0; i <data.nParam; i++) {
				exprf.addTerm(data.B[j][i], u[i]);
			}
			cplex.addLe(exprf, data.b[j]);
		}

		// add constraints follower
		for(int j=0; j < data.nConsF; j++){
			IloLinearNumExpr exprf = cplex.linearNumExpr();
			for (int i = 0; i <data.nParam; i++) {
				exprf.addTerm(data.C[j][i], u[i]);
			}
			for (int i = 0; i <data.nVar; i++) {
				exprf.addTerm(data.D[j][i], x[i]);
			}
			cplex.addLe(exprf, data.d[j]);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// ADD OBJECTIVE FUNCTION	
		IloLinearNumExpr obj = cplex.linearNumExpr();
		cplex.addMaximize(obj,"OBJ");

		// Find limit on leader influence for each follower constraint
		for (int j = 0; j < data.nConsF; j++) {
			for(int i=0; i<data.nVar; i++){
				cplex.setLinearCoef(cplex.getObjective(), data.D[j][i], x[i]);
			}
			cplex.solve();
			U[j] = (int) Math.round(cplex.getObjValue());
			System.out.println("--------------------- U "+j+": "+U[j]);
		}


		// Optimize model for each constraint
		for (int j = 0; j < data.nConsL; j++) {
			Realization s = new Realization(data); //to add to the sample
			for(int i=0; i<data.nVar; i++){
				cplex.setLinearCoef(cplex.getObjective(), data.A[j][i], x[i]);
			}

			cplex.solve();
			M[j] = (int) Math.round(cplex.getObjValue());
			System.out.println("--------------------- Big M "+j+": "+M[j]);

			for (int i = 0; i < data.nParam; i++) {
				if(cplex.getValue(u[i])>0.01) {s.u[i] = (int) Math.round(cplex.getValue(u[i]));}
			}
			if(!sMap.containsKey(Arrays.toString(s.u))) {
				s.computeGamma(data, criticalPoints, U); //also updates the critical points
				s.print(data);
				sample.add(s);
				sMap.put(Arrays.toString(s.u), sample.size());
			}
		}


		cplex.clearModel();
		cplex=null;
		System.gc();
	}

	public void cuttingPlane(DataHandler data, double Atime, int timeLimit) throws IloException {

		int timeUsed = (int) ((System.currentTimeMillis()-Atime)/1000);
		getBigM(data);		// Get big Ms and initialize sample

		while(UB > LB && timeUsed < timeLimit) {
			solveMasterBasic(data, timeLimit-timeUsed);
			solveMasterCP(data, timeLimit-timeUsed);
			solveMasterE(data, timeLimit-timeUsed);
			numMasterSolved++;
			
			solveWorstCase(data);
			numSubSolved++;
			timeUsed = (int) ((System.currentTimeMillis()-Atime)/1000);
			int numCritical = 0;
			for (int j = 0; j < data.nConsF; j++) {
				numCritical+= criticalPoints[j].size();
			}
			data.numCritical = numCritical;
			System.out.println("************************************************** LB "+LB+" Sample Size: "+sample.size()+" Total Critical Points: "+numCritical);
		}

		timeMasterB = timeMasterB/(numMasterSolved+0.0);
		timeMasterCP = timeMasterCP/(numMasterSolved+0.0);
		timeMasterE = timeMasterE/(numMasterSolved+0.0);
		timeSubProblem = timeSubProblem/(numSubSolved+0.0);

	}



}
