package RobustSensitivityExp;

import java.util.ArrayList;
import java.util.Arrays;

import ilog.concert.IloLinearNumExpr;

public class Realization {

	// Uncertainty vector
	int[] u;
	// Value to block the realization for each constraint
	int[] gamma; 

	Realization(DataHandler data){
		u = new int[data.nParam];
		gamma = new int[data.nConsF];
	}

	public void print(DataHandler data) {
		System.out.print("u: "+Arrays.toString(u));
		System.out.println(" gamma: "+Arrays.toString(gamma));
	}

	public void computeGamma(DataHandler data, ArrayList<Integer>[] criticalPoints, int[] U) {
		for(int j=0; j < data.nConsF; j++){
			int uContribution = 0;
			for (int i = 0; i <data.nParam; i++) {
				uContribution += data.C[j][i]*u[i];
			}
			gamma[j] = data.d[j]-uContribution+1;
			if(!criticalPoints[j].contains(gamma[j])) {
				if(gamma[j] <= U[j]) {
					criticalPoints[j].add(gamma[j]);
					//System.out.println("CRITICAL POINT ADDED FOR CONSTRAINT "+j+" : "+gamma[j]);
				}
				//else {
				//	System.out.println("GAMMA IS TOO LARGE, CANT BLOCK!!!!!");
				//}
			}
		}

	}

}
